#ifndef _UMEM_H_
#define _UMEM_H_

class Umem
{
    public:

        Umem();
        Umem(uint8_t *memory,uint32_t size);
        virtual ~Umem();

        virtual void setMem(uint8_t *memory,uint32_t size);
        virtual void *allocMem(uint32_t size);
        virtual void freeMem(void *ptr);

    private:

        void split(uint32_t addres,uint32_t size);
        void merge(uint32_t prev,uint32_t block,uint32_t next);

    private:

        uint8_t *_memory;
        uint32_t _size;
};

#endif
