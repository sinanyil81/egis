#ifndef CONSOLE_H_
#define CONSOLE_H_

#ifdef __cplusplus
extern "C" {
#endif
    void e_clear();
    void e_putc(char c);
    void e_puts(char *str);
#ifdef __cplusplus
}   /* extern "C" */
#endif

#endif

