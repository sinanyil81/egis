#ifndef EGIS_H_
#define EGIS_H_

namespace eGIS
{
    class e_Thread;
    class e_Mutex;
    class e_Semaphore;
};

#include "e_thread.h"
#include "e_mutex.h"
#include "e_semaphore.h"

#endif
