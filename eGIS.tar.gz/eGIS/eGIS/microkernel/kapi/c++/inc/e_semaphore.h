#ifndef E_SEMAPHORE_H_
#define E_SEMAPHORE_H_

class eGIS::e_Semaphore
{
    public:

        e_Semaphore();
        ~e_Semaphore();

        void init(uint32_t init_value);
        void post();
        void wait();

    private:

        eGIS_Semaphore *_semaphore;
};

#endif
