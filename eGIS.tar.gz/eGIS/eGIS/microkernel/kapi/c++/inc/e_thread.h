#ifndef E_THREAD_H_
#define E_THREAD_H_

class eGIS::e_Thread
{
    public:

        e_Thread(eGIS_TaskPriority priority);
        virtual ~e_Thread();

        void start();

        static void *MainEntry(void *param);

        virtual void entry() = 0;

    protected:

        eGIS_TaskId _pid;
        eGIS_TaskInfo _taskInfo;
};


#endif
