#ifndef E_MUTEX_H_
#define E_MUTEX_H_

class eGIS::e_Mutex
{
    public:

        e_Mutex();
        ~e_Mutex();

        void init();
        void lock();
        void unlock();

    private:

        eGIS_Mutex *_mutex;
};

#endif
