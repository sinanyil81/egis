#include "../../../include/egis_kernel.h"
#include "eGIS_c++.h"

using namespace eGIS;

/**
 * 
 */
e_Semaphore::e_Semaphore()
{
    _semaphore = 0;
}

/**
 * 
 */
e_Semaphore::~e_Semaphore()
{
    eGIS_IpcManager *IPCManager = eGIS_KERNEL->getIpcManager();
    IPCManager->freeSemaphore(_semaphore);
}

/**
 * 
 */
void e_Semaphore::init(uint32_t init_value)
{
    eGIS_IpcManager *IPCManager = eGIS_KERNEL->getIpcManager();
    _semaphore = IPCManager->allocSemaphore();
    _semaphore->init(init_value);
}

/**
 * 
 */
void e_Semaphore::post()
{
    _semaphore->post();
}

/**
 * 
 */
void e_Semaphore::wait()
{
    _semaphore->wait();
}
