#ifndef EGIS_TYPES_H_
#define EGIS_TYPES_H_

#include "egis_systemtypes.h"
#include "egis_object.h"

#endif

