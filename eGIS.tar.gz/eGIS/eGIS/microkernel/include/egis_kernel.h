#ifndef EGIS_KERNEL_H_
#define EGIS_KERNEL_H_

#include  "types/egis_types.h"
#include  "sys/sched/egis_sched.h"
#include  "sys/int/egis_int.h"
#include  "sys/kmem/egis_kmem.h"
#include  "sys/ipc/egis_ipc.h"
#include  "arch/egis_arch.h"

#define eGIS_KERNEL eGIS_Kernel::getKernel()

class eGIS_Kernel : public eGIS_Object
{
    public:

        virtual ~eGIS_Kernel();

        static eGIS_Kernel *getKernel();

        void setTaskManager(eGIS_TaskManager *task_manager);
        void setIpcManager(eGIS_IpcManager *ipc_manager);
        void setInterruptManager(eGIS_InterruptManager *interrupt_manager);

        eGIS_TaskManager *getTaskManager();
        eGIS_IpcManager *getIpcManager();
        eGIS_InterruptManager *getInterruptManager();

    protected:

        eGIS_Kernel();

    protected:

        static eGIS_Kernel *_kernel;

        eGIS_TaskManager *_taskManager;
        eGIS_IpcManager *_ipcManager;
        eGIS_InterruptManager *_interruptManager;
};

#endif
