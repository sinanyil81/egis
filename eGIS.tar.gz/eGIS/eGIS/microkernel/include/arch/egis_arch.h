#ifndef EGIS_ARCH_H_
#define EGIS_ARCH_H_

#include "arch_egis_interrupt.h"
#include "arch_egis_taskcontext.h"
#include "arch_egis_taskcontextfactory.h"

#endif

