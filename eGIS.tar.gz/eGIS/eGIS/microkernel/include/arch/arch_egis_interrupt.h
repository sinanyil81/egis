#ifndef ARCH_EGIS_INTERRUPT_H_
#define ARCH_EGIS_INTERRUPT_H_

class arch_eGIS_Interrupt : public eGIS_Object
{
    public:

        virtual void init() = 0;
        virtual void enableInts() = 0;
        virtual void disableInts() = 0;

        virtual void registerHandler(eGIS_InterruptNo  interrupt_no,eGIS_InterruptHandler handler = 0) = 0;
        virtual void unregisterHandler(eGIS_InterruptNo  interrupt_no) = 0;
};

#endif

