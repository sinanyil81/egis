#ifndef ARCH_EGIS_TASKCONTEXT_H_
#define ARCH_EGIS_TASKCONTEXT_H_

class arch_eGIS_TaskContext : public eGIS_Object
{
    public:

        virtual void init(eGIS_Object *init_param) = 0;
        virtual void switchTo(arch_eGIS_TaskContext *context) = 0;
}; 

#endif
