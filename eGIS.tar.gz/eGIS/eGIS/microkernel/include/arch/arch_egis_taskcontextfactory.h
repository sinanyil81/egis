#ifndef ARCH_EGIS_TASKCONTEXTFACTORY_H_
#define ARCH_EGIS_TASKCONTEXTFACTORY_H_

/**
 * platforma ozgu baglam bilgilerini tutan siniflari yaratan temel sinif
 * ( Factory tasarim deseni )
 */
class arch_eGIS_TaskContextFactory : public eGIS_Object
{
    public:

        /* platfomra ozgu baglamlari dondurur */
        virtual arch_eGIS_TaskContext *returnContext() = 0;
};

#endif

