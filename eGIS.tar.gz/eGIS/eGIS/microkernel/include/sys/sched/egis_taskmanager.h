#ifndef EGIS_TASKMANAGER_H_
#define EGIS_TASKMANAGER_H_

class eGIS_TaskManager : public eGIS_Object
{
    public :

        virtual void init() = 0;

        virtual eGIS_TaskId createTask(eGIS_TaskInfo *task_info) = 0;
        virtual void startTask(eGIS_TaskId task_id) = 0;

        virtual void waitTask(eGIS_TaskId task_id, eGIS_Object *obj) = 0;
        virtual void wakeUpTasks(eGIS_Object *obj) = 0;

        virtual eGIS_TaskId returnCurrentTask() = 0;
        virtual eGIS_TaskPriority returnPriority(eGIS_TaskId task_id) = 0;

        virtual void setSchedStatus(eGIS_SchedStatus) = 0;
};

#endif


