#ifndef EGIS_TASKINFO_H_
#define EGIS_TASKINFO_H_

class eGIS_TaskInfo : public eGIS_Object
{
    public:

        /* giris noktasi ve oncelik */
        eGIS_TaskEntryPoint _entry;
        eGIS_TaskEntryParameter _entryParam;
        eGIS_TaskPriority _priority;

        /* yigit bilgisi */
        eGIS_TaskStack _stack;
        eGIS_TaskStackSize _stackSize;

        /* ek ozellikler */
        eGIS_AdditionalTaskInfo _addInfo;
};

#endif



