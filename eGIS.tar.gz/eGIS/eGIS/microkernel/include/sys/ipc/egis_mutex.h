#ifndef EGIS_MUTEX_H_
#define EGIS_MUTEX_H_

class eGIS_Mutex : public eGIS_Object
{
    public:

        virtual void init() = 0;
        virtual void lock() = 0;
        virtual void unlock() = 0;
};

#endif

