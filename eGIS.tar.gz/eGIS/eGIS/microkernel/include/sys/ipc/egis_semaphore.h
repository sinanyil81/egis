#ifndef EGIS_SEMAPHORE_H_
#define EGIS_SEMAPHORE_H_

class eGIS_Semaphore : public eGIS_Object
{
    public:

        virtual void init(uint32_t init_value) = 0;
        virtual void post() = 0;
        virtual void wait() = 0;
};

#endif

