#ifndef EGIS_IPC_H_
#define EGIS_IPC_H_

#include "egis_mutex.h"
#include "egis_semaphore.h"
#include "egis_ipcmanager.h"

#endif

