#ifndef EGIS_IPCMANAGER_H_
#define EGIS_IPCMANAGER_H_

class eGIS_IpcManager : public eGIS_Object
{
    public:

        virtual eGIS_Mutex *allocMutex() = 0;
        virtual eGIS_Semaphore *allocSemaphore() = 0;
        virtual void freeMutex(eGIS_Mutex *) = 0;
        virtual void freeSemaphore(eGIS_Semaphore *) = 0;
};

#endif

