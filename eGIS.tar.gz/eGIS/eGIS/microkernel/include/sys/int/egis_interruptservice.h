#ifndef EGIS_INTERRUPT_SERVICE_H_
#define EGIS_INTERRUPT_SERVICE_H_

class eGIS_InterruptService : public eGIS_Object
{
    public:

        virtual void processInterrupt() = 0;
};


#endif

