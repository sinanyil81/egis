#ifndef EGIS_INTERRUPT_MANAGER_H_
#define EGIS_INTERRUPT_MANAGER_H_

class eGIS_InterruptManager : public eGIS_Object 
{
    public:

        virtual void init() = 0;

        virtual eGIS_IntStatus setIntStatus(eGIS_IntStatus) = 0;
        virtual eGIS_IntStatus getIntStatus() = 0;

        virtual void registerInterruptService(eGIS_InterruptNo interrupt_no,eGIS_InterruptService *service) = 0;
        virtual void unregisterInterruptService(eGIS_InterruptNo interrupt_no,eGIS_InterruptService *service) = 0;

        virtual void interruptEntry(eGIS_InterruptNo interrupt_no) = 0;
};


#endif
