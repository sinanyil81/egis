#include "../../../include/egis_kernel.h"

#include "../../../sys/kmem/ege_kmem/inc/ege_kmem.h"
#include "../../../../umem/inc/umem.h"

#include <stdlib.h>

#define KERNEL_MEMORY_SIZE  0x200000 
#define USER_MEMORY_SIZE  0x200000 

static eGe_Memory::eGe_Kmem KernelMemoryManager;
static Umem UserMemoryManager;

#define SYSTEM_MEMORY

#ifndef SYSTEM_MEMORY

/**
*
*/
void initLinuxMem()
{
    KernelMemoryManager.setMem((uint8_t *)malloc(KERNEL_MEMORY_SIZE),KERNEL_MEMORY_SIZE);

    UserMemoryManager.setMem((uint8_t *)malloc(USER_MEMORY_SIZE),USER_MEMORY_SIZE);
}

/**
 * 
 */
void *kmalloc(uint32_t size)
{
    return KernelMemoryManager.allocMem(size);
}

/**
 * 
 */
void kfree(void *ptr)
{
    return KernelMemoryManager.freeMem(ptr);
}

/**
 * 
 */
void* operator new (uint32_t size)
{
    return UserMemoryManager.allocMem(size);
}

/**
 * 
 */
void* operator new[] (uint32_t size)
{
    return UserMemoryManager.allocMem(size);
}

/**
 * 
 */
void operator delete (void *ptr)
{
    return UserMemoryManager.freeMem(ptr);
}

/**
 * 
 */
void operator delete[] (void * ptr)
{
    return UserMemoryManager.freeMem(ptr);
}

#else

/**
*
*/
void initLinuxMem()
{

}

/**
 * 
 */
void *kmalloc(uint32_t size)
{
    return malloc(size);
}

/**
 * 
 */
void kfree(void *ptr)
{
    return free(ptr);
}

/**
 * 
 */
void* operator new (uint32_t size)
{
    return malloc(size);
}

/**
 * 
 */
void* operator new[] (uint32_t size)
{
    return malloc(size);
}

/**
 * 
 */
void operator delete (void *ptr)
{
    return free(ptr);
}

/**
 * 
 */
void operator delete[] (void * ptr)
{
    return free(ptr);
}

#endif