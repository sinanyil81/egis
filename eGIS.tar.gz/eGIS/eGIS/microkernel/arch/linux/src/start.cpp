#include "../../../include/egis_kernel.h"
#include "linux.h"

#include <stdio.h>

extern "C" void eGIS_main();

int main(int)
{
    eGIS_main();
  
    while(1){

        sleep(1000);
        printf("Main thread...\n");

    }

    return 0;
}
