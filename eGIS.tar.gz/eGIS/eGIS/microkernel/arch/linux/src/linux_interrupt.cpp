#include "../../../include/egis_kernel.h"
#include "linux.h"

/**
* kesme olayini kesme yonetim sistemine iletir 
*/
extern "C" void InterruptEntry(uint32_t int_no)
{
    eGIS_InterruptManager *interruptManager = eGIS_KERNEL->getInterruptManager();

    interruptManager->interruptEntry(int_no);
}


/**
 *
 */
Linux_Interrupt::Linux_Interrupt()
{

}

/**
 *
 */
Linux_Interrupt::~ Linux_Interrupt()
{

}

/**
 *
 */
void Linux_Interrupt::init()
{

}

/**
 *
 */
void Linux_Interrupt::enableInts()
{
    
}

/**
 *
 */
void Linux_Interrupt::disableInts()
{
    
}

/**
 *
 */
void Linux_Interrupt::registerHandler(eGIS_InterruptNo  interrupt_no,eGIS_InterruptHandler handler)
{
    handler = handler;
}

/**
 * 
 */
void Linux_Interrupt::unregisterHandler(eGIS_InterruptNo  interrupt_no)
{

}
