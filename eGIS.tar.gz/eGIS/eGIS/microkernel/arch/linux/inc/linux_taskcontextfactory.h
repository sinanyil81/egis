#ifndef LINUX_TASKCONTEXTFACTORY_H_
#define LINUX_TASKCONTEXTFACTORY_H_

/**
 * Linux platformuna uygun baglam donduren fabrika sinifi 
 */
class Linux_TaskContextFactory : public arch_eGIS_TaskContextFactory
{
    public:

        /* platfomra ozgu baglamlari dondurur */
        arch_eGIS_TaskContext *returnContext();
};

#endif
