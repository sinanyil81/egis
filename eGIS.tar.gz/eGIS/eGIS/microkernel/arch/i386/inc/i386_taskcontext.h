#ifndef i386_TASKCONTEXT_H_
#define i386_TASKCONTEXT_H_

/**
 * intel 386 platformu icin donanimsal surec
 * bilgilerini tutacak olan sinif
 */
class i386_TaskContext : public arch_eGIS_TaskContext
{
    public :

        i386_TaskContext();
        virtual ~i386_TaskContext();

        void init(eGIS_Object *init_param);
        void switchTo(arch_eGIS_TaskContext *newContext);

    public :

        uint32_t *stack;
};

#endif

