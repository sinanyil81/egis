#ifndef i386_TASKCONTEXTFACTORY_H_
#define i386_TASKCONTEXTFACTORY_H_

/**
 * intel 386 platformuna uygun baglam donduren fabrika sinifi 
 */
class i386_TaskContextFactory : public arch_eGIS_TaskContextFactory
{
    public:

        /* platfomra ozgu baglamlari dondurur */
        arch_eGIS_TaskContext *returnContext();
};

#endif
