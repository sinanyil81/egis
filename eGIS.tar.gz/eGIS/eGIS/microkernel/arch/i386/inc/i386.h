#ifndef INTEL386_H_
#define INTEL386_H_

#include "i386_interrupt.h"
#include "i386_taskcontext.h"
#include "i386_taskcontextfactory.h"

#endif
