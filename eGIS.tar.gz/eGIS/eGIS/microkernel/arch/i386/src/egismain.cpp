#include "../../../include/egis_kernel.h"

#include "i386.h"

#include "../../../sys/sched/ege_sched/inc/ege_sched.h"
#include "../../../sys/int/ege_int/inc/ege_int.h"
#include "../../../sys/ipc/ege_ipc/inc/ege_ipc.h"

#include "../../../../libc/include/stdio.h"

extern int App_main();

/**
 * uygulama isparcacigi
 */
void *InitTask(void *)
{
    App_main();

    while(1);

    return (void *)0;
}

/**
 * hic bir surec calismadigi anda calisan is parcacigi
 */
void *IdleTask(void *)
{
    uint32_t dongu = 0;

    while(1)
    {
        printf("System Idle TASK...\n");
        dongu++;
    };
}

/**
 *
 */
void CreateInitTask()
{
    eGIS_TaskInfo taskInfo;

    eGIS_TaskManager  *TaskManager = eGIS_KERNEL->getTaskManager();

    taskInfo._entry = InitTask;
    taskInfo._entryParam = 0;
    taskInfo._priority = 62;
    taskInfo._stack = (void *)((uint32_t)(kmalloc(4096)) + 4096);
    taskInfo._stackSize = 4096;
    taskInfo._addInfo = 0;

    eGIS_TaskId pid = TaskManager->createTask(&taskInfo);
    TaskManager->startTask(pid);
}

/**
 * 
 */
void CreateIdleTask()
{
    eGIS_TaskInfo taskInfo;

    eGIS_TaskManager  *TaskManager = eGIS_KERNEL->getTaskManager();

    taskInfo._entry = IdleTask;
    taskInfo._entryParam = 0;
    taskInfo._priority = 63;
    taskInfo._stack = (void *)((uint32_t)(kmalloc(4096)) + 4096);
    taskInfo._stackSize = 4096;
    taskInfo._addInfo = 0;

    eGIS_TaskId pid = TaskManager->createTask(&taskInfo);
    TaskManager->startTask(pid);
}

/**
 * eGIS Sistem Girisi --> Sistemin baslangic ana noktasi
 */
extern "C" int eGIS_main()
{
    i386_TaskContextFactory TaskContextFactory;
    i386_Interrupt InterruptPlatform;

    eGe_Sched::eGe_TaskManager TaskManager(&TaskContextFactory);
    eGe_Int::eGe_InterruptManager InterruptManager(&InterruptPlatform);
    eGe_Ipc::eGe_IpcManager IpcManager;

    /* baslangic mesajlari */
    printf("eGIS ver 1.0...\n");
    printf("System initializing...\n");

    /* surec yonetim alt sistemi kaydediliyor */
    eGIS_KERNEL->setTaskManager(&TaskManager);
    printf("Task Manager Registered...\n");

    /* kesme yonetim sistemini ata */
    eGIS_KERNEL->setInterruptManager(&InterruptManager);
    printf("Interrupt Manager Registered...\n");

    /* haberlesme sistemini ata */
    eGIS_KERNEL->setIpcManager(&IpcManager);
    printf("IPC Manager Registered...\n");

    InterruptManager.init();
    printf("Interrupt System Initialized...\n");    

    TaskManager.init();
    printf("Task System Initialized...\n");

    /* sistem sureclerini yarat */
    CreateInitTask();
    CreateIdleTask();
    printf("Main Taks Created...\n");

    /* isletim sistemini baslat */
    InterruptManager.setIntStatus(INT_ON);
    TaskManager.setSchedStatus(SCHED_ON);

    return 0;
}
