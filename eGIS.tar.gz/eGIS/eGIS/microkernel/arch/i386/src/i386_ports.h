#ifndef i386_PORTS_H_
#define i386_PORTS_H_

/** 
 * PIC programlanmasi icin gerekli olan port adresleri
 * Bu port numaralari kullanilarak donanim kesmeleri tasinacaktir. Ayrica sistemin 
 * kesmelere tam olarak yan�t vermesi i�in, PIC programlamasinin yapilmasi 
 * ve gereken parametrelerin verilmesi sarttir.BIOS bunu acilista yapsa da , 
 * uyumluluk acisindan tekrar yapilmasi daha uygundur.
 */
#define PIC_MASTER_PORT_0 0x20    /* ICW1'in g�nderilece�i port numaras� (PIC1) */
#define PIC_MASTER_PORT_1 0x21    /* ICW2,ICW3 ve ICW4'�n gonderilecegi port numarasi (PIC1) */
#define PIC_SLAVE_PORT_0 0x0A0    /* PIC2 i�in ilk port */
#define PIC_SLAVE_PORT_1 0x0A1    /* PIC2 i�in 2. port */
#define EOI 0x20

/* PIT programlanmasi i�in gerekli portlar */
#define PIT_1_COUNTER_0  0x40
#define PIT_1_COUNTER_1  0x41
#define PIT_1_COUNTER_2  0x42
#define PIT_1_CONTROL_REGISTER 0x43
#define PIT_2_COUNTER_0  0x48
#define PIT_2_COUNTER_1  0x49
#define PIT_2_COUNTER_2  0x4A
#define PIT_2_CONTROL_REGISTER 0x4B

/**
 * 8042 Klavye denetleyicisinin programlanabilmesi i�in gerekli olan portlar
 * Bu port numaralari A20 adres bacaginin aktif hale getirilmesi i�in kullanilabilir.
 */
#define KEYBOARD_DATA_REGISTER  0x60
#define KEYBOARD_COMMAND_REGISTER  0x64  //komut yazma
#define KEYBOARD_STATUS_REGISTER  0x64   //durum bilgisi alma


#define out_port(value,port)                \
{                                           \
    asm volatile(   "outb %%al,%%dx \n\t"   \
                    "nop \n\t"              \
                    "nop"                   \
                    ::"a"(value),"d"(port));\
}
            
#define in_port(port)    (                  \
{                                           \
    unsigned char value;                    \
    asm volatile (  "inb %%dx,%%al \n\t"    \
                    "nop \n\t"              \
                    "nop"                   \
                    :"=a"(value)            \
                    :"d"(port));            \
                                            \
                    value;                  \
})                                          \

#endif

