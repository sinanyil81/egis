#include "../../../include/egis_kernel.h"
#include "i386.h"
#include "i386_descriptors.h"

/**
 * ilkleyici metod
 */
i386_TaskContext::i386_TaskContext()
{
    this->stack = 0x0;
}

/**
 * sonlandirici metod
 */
i386_TaskContext::~i386_TaskContext()
{

}

/**
 * surece ait baglami ilkler. Boylelikle surec duzgun bir sekilde 
 * calismaya baslayabilecektir.
 */
void i386_TaskContext::init(eGIS_Object *init_param)
{
    uint32_t *stackPtr;
 
    /* surecin bilgilerinin saklanacagi yigiti al */
    eGIS_TaskInfo *task_info = (eGIS_TaskInfo *)init_param;
    stackPtr     = (uint32_t *)task_info->_stack;

    /* parametre aktariliyor */
    *--stackPtr  = (uint32_t)task_info->_entryParam;

    /* surec hicbir zaman donmeyecegi icin buraya sallama bir adres de 
     * yazabiliriz. yine de surecin baslangicini yazalim */
    *--stackPtr  = (uint32_t)task_info->_entry;

    /* IRET ile alicanak sekilde yigita IP ve PSW yi yerlestir */
    *--stackPtr  = 0x00000202;     /* EFlags */
    *--stackPtr  = CS_SELEKTORU;   /* CS */
    *--stackPtr  = (uint32_t)task_info->_entry;  /* EIP */

    /* POPA sirasiyla alinacak sekilde genel amacli yazmaclari yigita yerlestir */  
    *--stackPtr  = 0x0a;     /* EAX */
    *--stackPtr  = 0x0c;     /* ECX */
    *--stackPtr  = 0x0d;     /* EDX */
    *--stackPtr  = 0x0b;     /* EBX */
    *--stackPtr  = 0xff;     /* ESP */
    *--stackPtr  = 0xfe;     /* EBP */
    *--stackPtr  = 0xfd;     /* ESI */
    *--stackPtr  = 0xfc;     /* EDI */  

    /* ES ve DS'yi simdilik saklamaya gerek yok. tum surecler icin ayni */

    /* ESP -> su anki yigiti gostersin */
    *(stackPtr - 4) = (uint32_t)stackPtr;

    this->stack = (uint32_t *)stackPtr;
}

/**
 * surecler arasi gecisin yapildigi metod.
 */
void i386_TaskContext::switchTo(arch_eGIS_TaskContext *newContext)
{
    i386_TaskContext *context = (i386_TaskContext *)newContext;

    /* surecin kendi kendine atlamasini engelle */
    if(newContext != this)
    {
        /* eski sureci sakla */
        asm volatile (  "pushfl \n\t"           /* Flags */
                        "pushl %%cs \n\t"       /* CS */
                        "pushl 4(%%ebp) \n\t"   /* Eip */
                        "pushal \n\t"           /* Tum yazmaclar */
                        "movl %%esp,%0 \n\t"
                        :"=r"(stack)
                        :);
    }

    /* yeni surece gecis yap */
    asm volatile (  "movl %0,%%esp \n\t"
                    "popal"
                    :
                    :"r"(context->stack));

    /* yeni surece kaldigi yerden devam et */
    asm volatile (  "iretl"::);
}
