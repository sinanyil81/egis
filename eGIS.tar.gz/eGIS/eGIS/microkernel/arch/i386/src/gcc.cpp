/*
 * 
 * Bu dosya GCC derleyicisi icin statik ve global nesnelerin ilklenmesi
 * icin gerekli olan metodlari icermektedir. Bunlar olmadan kodumuz 
 * derlenmemekte  ne yazikki... 
 * 
 */

/* Sanal fonksiyonlar icin gcc'nin kullandigi fonksiyon*/
extern "C" void __cxa_pure_virtual()
{
    /* sanal fonksiyonlar icin */
}


/* tum global nesnelere ait ilkleyici metodlar cagirilir */
extern "C" void _main()
{
    extern void (*__startBSS)();
    extern void (*__endBSS)();

    extern void (*__CTOR_LIST__)() ;

    int sayi = ((int)&__endBSS - (int)&__startBSS);
    char *c = (char *)&__startBSS;

    for(int i=0;i<sayi;i++)
    {
        *c++ = 0;
    }

    void (**constructor)() = &__CTOR_LIST__ ;

    int total = *(int *)constructor ;

    constructor++ ;

    while(total)
    {
        (*constructor)() ;
        total-- ;
        constructor++ ;
    }
}

/* tum global nesnelere ait sonlandirici metodlar cagirilir */
extern "C" void _atexit()
{
    extern void (*__DTOR_LIST__)() ;

    void (**deconstructor)() = &__DTOR_LIST__ ;

    int total = *(int *)deconstructor ;

    deconstructor++ ;

    while(total)
    {
        (*deconstructor)() ;
        total-- ;
        deconstructor++ ;
    }
}

void *__dso_handle; 

struct object
{
        void (*f)(void*);
        void *p;
        void *d;
} object[32] = {0};
unsigned int iObject = 0;

extern "C" int __cxa_atexit(void (*f)(void *), void *p, void *d)
{
        if (iObject >= 32) return -1;
        object[iObject].f = f;
        object[iObject].p = p;
        object[iObject].d = d;
        ++iObject;
        return 0;
}

extern "C" void __cxa_finalize(void *d)
{
    d=d;
    unsigned int i = iObject;
    for (; i > 0; --i)
    {
            --iObject;
            object[iObject].f(object[iObject].p);
    }
}

/**
 * Performans olcumleri icin
 */
extern "C" inline unsigned long long int rdtsc()
{
    unsigned long long int x;

    asm volatile (".byte 0x0f, 0x31" : "=A" (x));

    return x;
}
