#include "../../../include/egis_kernel.h"

#include "../../../sys/kmem/ege_kmem/inc/ege_kmem.h"
#include "../../../../umem/inc/umem.h"

#define KERNEL_MEMORY       0x600000 
#define KERNEL_MEMORY_SIZE  0x200000 

#define USER_MEMORY       0x400000 
#define USER_MEMORY_SIZE  0x200000 

static eGe_Memory::eGe_Kmem KernelMemoryManager((uint8_t *)KERNEL_MEMORY,KERNEL_MEMORY_SIZE);

static Umem UserMemoryManager((uint8_t *)USER_MEMORY, USER_MEMORY_SIZE);


/**
 * 
 */
void *kmalloc(uint32_t size)
{
    return KernelMemoryManager.allocMem(size);
}

/**
 * 
 */
void kfree(void *ptr)
{
    return KernelMemoryManager.freeMem(ptr);
}

/**
 * 
 */
void* operator new (uint32_t size)
{
    return UserMemoryManager.allocMem(size);
}

/**
 * 
 */
void* operator new[] (uint32_t size)
{
    return UserMemoryManager.allocMem(size);
}

/**
 * 
 */
void operator delete (void *ptr)
{
    return UserMemoryManager.freeMem(ptr);
}

/**
 * 
 */
void operator delete[] (void * ptr)
{
    return UserMemoryManager.freeMem(ptr);
}
