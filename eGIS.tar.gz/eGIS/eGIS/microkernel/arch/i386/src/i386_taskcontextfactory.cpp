#include "../../../include/egis_kernel.h"
#include "i386.h"

/**
 * intel 386 platformu icin yeni bir s�rec baglami yaratir.
 */
arch_eGIS_TaskContext *i386_TaskContextFactory::returnContext()
{
    return new i386_TaskContext();
}
