#include "i386_descriptors.h"

/**
 * Fonksiyon parametre olarak verilen bellek tanimlayicisini, yine parametre
 * olarak verilen tanimlayici bilgileri ile doldurur.
 * 
 * Parametreler :
 *    desc      -> doldurulacak tanimlayici
 *    limit     -> tanimlayici limiti
 *    base      -> tanimlayicinin isaret ettigi bellek bolgesinin baslangic adresi
 *    access    -> tanimlayicinin erisim haklari
 *    size      -> tanimlayicinin b�y�kl�g� ile ilgili bilgiler
 * 
 * Geri D�n�� De�eri:
 *  YOK
 */
void FillDescriptor(struct i386_Descriptor *desc,
                       unsigned long limit,
                       unsigned long base,
                       unsigned char access,
                       unsigned char size)
{
    desc->limit_low = limit & 0xffff;
    desc->base_low = base & 0xffff;
    desc->base_mid = (base >> 16) & 0xff;
    desc->access_rights = access;
    desc->limit_high = (limit >> 16) & 0xf;
    desc->size = size & 0xf;
    desc->base_high = (base >> 24) & 0xff;
}

/**
 * Fonksiyon parametre olarak verilen Gate'i, yine parametre
 * olarak verilen bilgiler ile doldurur.
 * 
 * Parametreler :
 *    gate              -> doldurulacak Gate
 *    offset            -> Gate'in o segment i�inde isaret ettigi fonksiyon ofseti
 *    selector          -> Sistem bellek tablolarinda isaret edilen segment
 *    parametre_sayisi  ->
 *    access            -> Gate erisim haklari
 * 
 *  Geri D�n�s Degeri:
 *    YOK
 */
void FillGate(struct i386_Gate *gate,
                 unsigned long offset,
                 unsigned short selector,
                 unsigned char parametre_sayisi,
                 unsigned char access)
{
    gate->offset_low = offset & 0xffff ;
    gate->selector = selector ;
    gate->p_count = parametre_sayisi ;
    gate->access_rights = access | PRESENT ;
    gate->offset_high = (offset >> 16) & 0xffff;
}
