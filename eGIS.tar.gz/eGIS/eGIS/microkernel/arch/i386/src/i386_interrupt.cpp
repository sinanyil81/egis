#include "../../../include/egis_kernel.h"
#include "i386.h"

#include "i386_descriptors.h"
#include "i386_ports.h"

extern "C" {

/* i386_int.asm'den */
extern void Default_Interrupt();
extern void IRQ0();
extern void IRQ1();
extern void IRQ2();
extern void IRQ3();
extern void IRQ4();
extern void IRQ5();
extern void IRQ6();
extern void IRQ7();
extern void IRQ8();
extern void IRQ9();
extern void IRQ10();
extern void IRQ11();
extern void IRQ12();
extern void IRQ13();
extern void IRQ14();
extern void IRQ15();
extern void DivideError();
extern void DebugException();
extern void NMIInterrupt();
extern void BreakPointException();
extern void OverFlowException();
extern void BoundRangeExceeded();
extern void InvalidOpcodeException();
extern void DeviceNotAvailable();
extern void DoubleFaultException();
extern void CoprocessorSegmentOverrun();
extern void InvalidTSSException();
extern void SegmentNotPresent();
extern void StackFaultException();
extern void GeneralProtectionException();
extern void PageFaultException();
extern void Reserved();
extern void FloatingPointError();

};

/**
* kesme olayini kesme yonetim sistemine iletir 
*/
extern "C" void InterruptEntry(uint32_t int_no)
{
    eGIS_InterruptManager *interruptManager = eGIS_KERNEL->getInterruptManager();

    interruptManager->interruptEntry(int_no);
}


/**
 *
 */
i386_Interrupt::i386_Interrupt()
{

}

/**
 *
 */
i386_Interrupt::~ i386_Interrupt()
{

}

/**
 *
 */
void i386_Interrupt::init()
{
    uint32_t i;

    /* IDT 0x0 fiziksel adresinde */
    struct i386_Descriptor *Interrupt_Descriptor_Table = 0x0;

    /* sistemde olusabilecek istisnalari y�nlendirecek olan 
     * IDT tablosu sirasi ile dolduruluyor. */

    /* 0 ile b�lme hatasi */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0],
                (unsigned long)DivideError,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* Debug Exception */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[1],
                (unsigned long)DebugException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* NMI Interrupt */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[2],
                (unsigned long)NMIInterrupt,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* BreakPoint Exception */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[3],
                (unsigned long)BreakPointException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* OverFlowException */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[4],
                (unsigned long)OverFlowException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* BoundRangeExceeded */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[5],
                (unsigned long)BoundRangeExceeded,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* InvalidOpcodeException */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[6],
                (unsigned long)InvalidOpcodeException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* DeviceNotAvailable */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[7],
                (unsigned long)DeviceNotAvailable,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* DoubleFaultException */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[8],
                (unsigned long)DoubleFaultException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* CoprocessorSegmentOverrun */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[9],
                (unsigned long)CoprocessorSegmentOverrun,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* InvalidTSSException */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[10],
                (unsigned long)InvalidTSSException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* SegmentNotPresent */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[11],
                (unsigned long)SegmentNotPresent,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* StackFaultException */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[12],
                (unsigned long)StackFaultException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* GeneralProtectionException */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[13],
                (unsigned long)GeneralProtectionException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* PageFaultException */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[14],
                (unsigned long)PageFaultException,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* Reserved */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[15],
                (unsigned long)Reserved,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);

    /* FloatingPointError */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[16],
                (unsigned long)FloatingPointError,
                CS_SELEKTORU,
                0,
                TRAP_GATE|PRESENT);


    /* 17 ve 32 numarali kesmeler Intel tarafindan daha sonra kullanilmak
     * icin ayrilmistir.Bu sebeple bu kesmelere ait fonksiyonlar sabit
     * bir yonetici fonksiyonu g�stermektedir. */
    for(i=17;i<32;i++)
    {
        FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[i],
                    (unsigned long)Reserved,
                    CS_SELEKTORU,
                    0,
                    TRAP_GATE|PRESENT);
    }

    /* Geriye kalan kesmelerin hepsi VarsayilanKesme ile dolduruluyor. */
    for(i=32;i<256;i++)
    {
        FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[i], 
                    (unsigned long)Default_Interrupt,
                    CS_SELEKTORU,
                    0,
                    INTERRUPT_GATE|PRESENT);
    }

    /* IRQ kesmelerini doldur */ 

    /* Zamanlayici kesmesini isleyecek kod parcasi IDT'ye islensin */
    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x70],
                (unsigned long)IRQ8,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x71],
                (unsigned long)IRQ9,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x72],
                (unsigned long)IRQ10,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x73],
                (unsigned long)IRQ11,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x74],
                (unsigned long)IRQ12,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x75],
                (unsigned long)IRQ13,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x76],
                (unsigned long)IRQ14,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x77],
                (unsigned long)IRQ15,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x78],
                (unsigned long)IRQ0,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x79],
                (unsigned long)IRQ1,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x7A],
                (unsigned long)IRQ2,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x7B],
                (unsigned long)IRQ3,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x7C],
                (unsigned long)IRQ4,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x7D],
                (unsigned long)IRQ5,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x7E],
                (unsigned long)IRQ6,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    FillGate((struct i386_Gate *)&Interrupt_Descriptor_Table[0x7F],
                (unsigned long)IRQ7,
                CS_SELEKTORU,
                0,
                INTERRUPT_GATE|PRESENT);

    /* IRQ'lar kapansin */
    out_port(0xff,PIC_MASTER_PORT_1);

}

/**
 *
 */
void i386_Interrupt::enableInts()
{
    asm volatile ("sti"::);
}

/**
 *
 */
void i386_Interrupt::disableInts()
{
    asm volatile ("cli"::);
}

/**
 *
 */
void i386_Interrupt::registerHandler(eGIS_InterruptNo  interrupt_no,eGIS_InterruptHandler handler)
{
    handler = handler;

    switch (interrupt_no)
    {
        case IRQ_8:
            /* IRQ 0 = Zamanlayici Kesmesi aktif hale getiriliyor... */
            /* kesme maskesi aliniyor */
            uint8_t value = in_port(PIC_MASTER_PORT_1);
            /* IRQ 0 aktif hale gelsin */
            out_port((value&0xfe),PIC_MASTER_PORT_1);

            break;
    };
}

/**
 * 
 */
void i386_Interrupt::unregisterHandler(eGIS_InterruptNo  interrupt_no)
{
    switch (interrupt_no)
    {
        case IRQ_8:
            /* IRQ 0 = Zamanlayici Kesmesi aktif hale getiriliyor... */
            /* kesme maskesi aliniyor */
            uint8_t value = in_port(PIC_MASTER_PORT_1);
            /* IRQ 0 kapansin */
            out_port((value&0xff),PIC_MASTER_PORT_1);

            break;
    };
}
