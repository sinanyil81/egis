#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    char buf[512];
    FILE *f;
    size_t n;
    size_t nsectors;
    int i;
       
    f = fopen("boot.out", "rb");
    n = fread(buf, 1, 512, f);
    fclose(f);

    memset(buf + n, 0, 510 - n);
    buf[510] = 0x55;
    buf[511] = 0xAA;
    
    fwrite(buf, 1, 512, stdout);
    
    return 0;
}
