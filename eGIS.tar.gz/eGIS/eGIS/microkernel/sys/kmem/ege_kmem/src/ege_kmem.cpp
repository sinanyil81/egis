#include "../../../../include/egis_kernel.h"
#include "ege_kmem.h"

using namespace eGe_Memory;

/*
          |0 3|       |4 7|        | 8 |      |9 12|   |13 .. n|
        [onceki]  [sonraki]  [durum]  [boyut]  [adres]
*/

#define PREV(i)   (*((uint32_t *)(&_memory[i-13])))
#define NEXT(i)  (*((uint32_t *)(&_memory[i-9])))
#define STATE(i)    (*((uint8_t *)(&_memory[i-5]))) 
#define SIZE(i) (*((uint32_t *)(&_memory[i-4])))

#define FREE 0
#define USED 1

#define START          13 
#define HEADER_SIZE   13

/**
 *
 */
eGe_Kmem::eGe_Kmem(uint8_t *memory,uint32_t size)
{
    _memory = memory;
    _size = size;

    PREV(START)   = 0;
    NEXT(START)  = 0;
    STATE(START)    = FREE;
    SIZE(START) = _size - HEADER_SIZE;
}

/**
 *
 */
eGe_Kmem::eGe_Kmem()
{
}

/**
 *
 */
eGe_Kmem::~eGe_Kmem()
{

}

/**
*
*/
void eGe_Kmem::setMem(uint8_t *memory,uint32_t size)
{
    _memory = memory;
    _size = size;

    PREV(START)   = 0;
    NEXT(START)  = 0;
    STATE(START)    = FREE;
    SIZE(START) = _size - HEADER_SIZE;
}

/**
 * TODO : mutexle koruma ekle
 */
void *eGe_Kmem::allocMem(uint32_t size)
{
    uint32_t i;

    if(size == 0)
    {
        return 0x0;
    }

    i = START;

    /* bellegi dolas */
    while(NEXT(i) !=0 )
    {
        /* istedigimiz buyuklugu karsilayabilecek ve bos olan
         * bir bellek blogunu bul*/
        if((SIZE(i)>= size) && (STATE(i)==FREE))
        {
            split(i,size);

            return (void *)&_memory[i];
        }

        i = NEXT(i);
    }

    /* son bloga da bak */
    if((SIZE(i)>=size)&& (STATE(i)==FREE))
    {
        split(i,size);

        return (void*)&_memory[i];
    }

    return 0x0;
}

/**
 *
 */
void eGe_Kmem::split(uint32_t addres,uint32_t size)
{

    /* o anki bos blok tum istegimizi karsilayabilecek buyuklukte mi yoksa
     * daha mi buyuk ? */
    if(SIZE(addres) >= size + HEADER_SIZE + HEADER_SIZE)
    {
        /* blok daha da buyuk*/

        uint32_t oldNext;
        uint32_t oldPrev;
        uint32_t oldSize;
        uint32_t newAddres;

        oldNext = NEXT(addres);
        oldPrev  = PREV(addres);
        oldSize= SIZE(addres);

        newAddres = addres + size + HEADER_SIZE;

        NEXT(addres)  = newAddres;
        PREV(addres)   = oldPrev;
        STATE(addres)    = USED;
        SIZE(addres) = size;

        NEXT(newAddres)  = oldNext;
        PREV(newAddres)   = addres;
        STATE(newAddres)    = FREE;
        SIZE(newAddres) = oldSize - size - HEADER_SIZE;
    }
    else
    {
        /* blok tam istedigimiz boyutta */
        STATE(addres) = USED;
    }

    return;

}

/**
 * 
 */
void eGe_Kmem::merge(uint32_t prev,uint32_t block,uint32_t next)
{
    /* hafiza uzayinin basi mi? */
    if(prev==0)
    {
        if(next==0)
        {
            STATE(block) = FREE;
        }
        else if(STATE(next) == USED)
        {
            STATE(block) = FREE;
        }
        else if(STATE(next) == FREE)
        {
            uint32_t tmp;

            STATE(block)    = FREE;
            SIZE(block) = SIZE(block) + SIZE(next) + HEADER_SIZE;
            NEXT(block) = NEXT(next);
            tmp = NEXT(next);
            PREV(tmp) = block;
        }
    }
    /* hafiza uzayinin sonu mu ? */
    else if(next==0)
    {
        if(STATE(prev) == USED)
        {
            STATE(block) = FREE;
        }
        else if(STATE(prev) == FREE)
        {
            SIZE(prev) = SIZE(prev) + SIZE(block) + HEADER_SIZE;
            NEXT(prev) = NEXT(block);
        }
    }
    /* 4 tane durumu da incekle */
    else if( (STATE(prev) == USED) && (STATE(next) == USED) )
    {
        STATE(block) = FREE;
    }
    else if( (STATE(prev) == USED) && (STATE(next) == FREE))
    {
        uint32_t tmp;

        STATE(block) = FREE;
        SIZE(block)  = SIZE(block) + SIZE(next) + HEADER_SIZE;
        NEXT(block)  = NEXT(next);
        tmp          = NEXT(next);

        if(tmp!=0)
        { 
            PREV(tmp) = block; 
        }
    }
    else if( (STATE(prev) == FREE) && (STATE(next) == USED))
    {
        SIZE(prev)    = SIZE(prev) + SIZE(block) + HEADER_SIZE;
        NEXT(prev)     = NEXT(block);
        PREV(next)     = prev;
    }
    else if( (STATE(prev) == FREE) && (STATE(next) == FREE))
    {
        uint32_t tmp;

        SIZE(prev) =  SIZE(prev) + SIZE(block) + HEADER_SIZE +           SIZE(next) + HEADER_SIZE ;

        NEXT(prev) = NEXT(next);
        tmp = NEXT(next);

        if(tmp != 0)
        { 
            PREV(tmp) = prev; 
        }
    }

    return;
}

/**
 * 
 */
void eGe_Kmem::freeMem(void *ptr)
{
    uint32_t i; 

    /* adres bos mu */
    if(ptr == 0x0)
    {
        return;
    }

    /* adres RAM sinirlarini asiyor mu? */
    if( (ptr >= (void*)&this->_memory[this->_size]) || 
        (ptr <  (void*)&this->_memory[0]))
    {
        return;
    }

    /* RAM ' deki indekse cevir */
    i = (uint32_t)( ((uint8_t *)ptr) - &this->_memory[0] );

    if( i < 13 )
    {
        return;
    }


    if( (STATE(i) != USED) ||
        (PREV(i) >= i)    ||
        (NEXT(i) >= this->_size) || 
        (SIZE(i) >= this->_size)||
        (SIZE(i) == 0)) 
    {
        return;
    }

    merge(PREV(i),i,NEXT(i));

    return;
}
