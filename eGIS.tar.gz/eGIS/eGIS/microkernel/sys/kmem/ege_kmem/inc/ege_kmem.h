#ifndef eGe_KMEM_H_
#define eGe_KMEM_H_

namespace eGe_Memory
{
    class eGe_Kmem;
};

class eGe_Memory::eGe_Kmem
{
    public:

        eGe_Kmem();
        eGe_Kmem(uint8_t *memory,uint32_t size);
        virtual ~eGe_Kmem();

        virtual void setMem(uint8_t *memory,uint32_t size);
        virtual void *allocMem(uint32_t size);
        virtual void freeMem(void *ptr);

    private:

        void split(uint32_t addres,uint32_t size);
        void merge(uint32_t prev,uint32_t block,uint32_t next);

    private:

        uint8_t *_memory;
        uint32_t _size;
};

#endif
