#include "../../../../include/egis_kernel.h"
#include "ege_sched.h"

using namespace eGe_Sched;

/*
 * bit pozisyonlarinin maskelenmesini saglayan
 * maske tablosu
 */
static const uint8_t PriorityTbl[] =
{
    0x01,
    0x02,
    0x04,
    0x08,
    0x10,
    0x20,
    0x40,
    0x80
};

/* seviye durum bitleri ve o seviyedeki nesnenin bitlerinin 
 * yardimi ile,nesnenin gercek onceligini bulunmasini sag-
 * layan degerleri iceren tablodur.
 */
static const uint8_t UnmapTbl[] =
{
    0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
};


/* oncelik 8 bitle ifade ediliyor. 64 nesne olacagi icin 6 bit 
 * yeterli. 6 bitin sagdan 3 biti oncelik seviyesi icindeki 
 * nesne numarasini tutuyor ( 1 seviyede 8 surec var ). Diger 3
 * bit ise oncelik seviyesini tutuyor. 
 *
 *  xxss syyy ( 8 bit oncelik )
 *    || ||||___
 *    || |||____  Nesne Yeri
 *    || ||_____
 *    || |__
 *    ||____  Oncelik seviyesi
 *    |_____
 */ 
 
/* verilen bir oncelikten oncelik seviyesi bulunur */
#define PRIORITY_LEVEL_MASK 0x38

/* verilen bir oncelikten, o oncelikteki surec yeri bulunur */
#define PRIORITY_BIT_MASK 0x07

/**
 * ilkleyici metod
 */
eGe_PriorityQueue::eGe_PriorityQueue()
{
    uint16_t i;

    /* task tablosunu 0'la */
    for(i=0 ; i<NUM_TASKS; i++)
    {
        _tasks[i] = 0x0;
    }

    /* nesnelerin isaretlendigi bit tablosu */
    for(i=0 ; i<NUM_PRIORITY_LEVEL; i++)
    {
        _ReadyTable[i] = 0x0;
    }

    /* oncelik bilgilerini 0'la */
    _ReadyLevel = 0x0;
}

/**
* sureclerin tutuldugu tabloya sureci ekler ve eklenilen 
* oncelige ait biti tabloda 1'ler
*/
void eGe_PriorityQueue::addTask(eGe_Task *task)
{
    uint8_t priorityLevel;
    uint8_t priorityBits;

    /* taski tabloya ekle */
    _tasks[task->_priority] = task;

    /* taska ait oncelik seviyesini, ve o oncelik seviyesindeki
     * bit yerini bul */
    priorityLevel = (task->_priority & PRIORITY_LEVEL_MASK)>>3;
    priorityBits = task->_priority & PRIORITY_BIT_MASK;

    /* o oncelik seviyesine ait biti 1'le */
    _ReadyLevel |= PriorityTbl[priorityLevel];

    /* o oncelik seviyesinde, nesneye ait biti 1'le */
    _ReadyTable[priorityLevel] |= PriorityTbl[priorityBits];
}

/**
 * surec kuyrugundan bir surec cikartir ve takip yapilan 
 * ilgili bitleri 0'lar.
 */
void eGe_PriorityQueue::removeTask(eGe_Task *task)
{
    uint8_t priorityLevel;
    uint8_t priorityBits;

    /* sureci tablodan cikart */
    _tasks[task->_priority] = 0x0;

    /* taska ait oncelik seviyesini, ve o oncelik seviyesindeki
     * bit yerini bul */
    priorityLevel = (task->_priority & PRIORITY_LEVEL_MASK)>>3;
    priorityBits = task->_priority & PRIORITY_BIT_MASK;

    /* o oncelik seviyesinde, surece ait biti 0'la */
    _ReadyTable[priorityLevel] &= ~PriorityTbl[priorityBits];

    /* eger o seviyed hic nesne kalmadiysa, seviye bitini 0'la */
    if(!_ReadyTable[priorityLevel])
    {
        /* o oncelik seviyesine ait biti 0'la */
        _ReadyLevel &= ~PriorityTbl[priorityLevel];
    }
}

/**
 * oncelik seviyelerini inceleyerek, en oncelikli nesneyi dondurur
 */
eGe_Task *eGe_PriorityQueue::returnHighesPriorityTask()
{
    uint8_t priorityLevel;
    uint8_t priorityBits;

    /* en oncelikli olan oncelik seviyesini bul */
    priorityLevel = UnmapTbl[_ReadyLevel];

    /* o seviyeye ait nesneleri elde et */
    priorityBits = _ReadyTable[priorityLevel];

    /* ilgili sureci dondur */
    return _tasks[(priorityLevel << 3) | (UnmapTbl[priorityBits])];
}

