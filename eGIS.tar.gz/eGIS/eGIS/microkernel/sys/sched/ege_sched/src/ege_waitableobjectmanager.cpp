#include "../../../../include/egis_kernel.h"
#include "ege_sched.h"

using namespace eGe_Sched;

/**
 *
 */
void eGe_WaitableObjectManager::waitTask(eGe_Task *task, eGIS_ObjectId oid)
{
    _waitingQueues[oid].addTask(task);
    task->_state = TASK_WAITING;
}


/**
 *
 */
eGe_Task *eGe_WaitableObjectManager::wakeUpTasks(eGIS_ObjectId oid)
{
    eGe_Task *task = _waitingQueues[oid].returnHighesPriorityTask();

    if(task)
    {
        _waitingQueues[oid].removeTask(task);
    }

    return task;
}
