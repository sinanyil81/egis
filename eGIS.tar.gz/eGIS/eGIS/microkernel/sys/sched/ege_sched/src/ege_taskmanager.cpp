#include "../../../../include/egis_kernel.h"
#include "ege_sched.h"

using namespace eGe_Sched;

/**
 *
 */
eGe_TaskManager::eGe_TaskManager(arch_eGIS_TaskContextFactory *contextFactory)
{
    _contextFactory = contextFactory;
}

/**
 *
 */
void eGe_TaskManager::init()
{

}

/**
 *
 */
void eGe_TaskManager::setSchedStatus(eGIS_SchedStatus status)
{
    eGIS_InterruptManager *intManager = eGIS_KERNEL->getInterruptManager();
    eGIS_IntStatus oldIntStatus = intManager->setIntStatus(INT_OFF);

    _scheduler._status = status;
    _scheduler.schedule();

    intManager->setIntStatus(oldIntStatus);
}

/**
 *
 */
eGIS_TaskId eGe_TaskManager::createTask(eGIS_TaskInfo *task_info)
{
    /* surec havuzundan bir surec al */
    eGe_Task *newTask = _taskPool.allocTask();

    if(newTask)
    {
        /* surec ozelliklerini ilkle */
        newTask->_pid = (eGIS_TaskId)newTask;

        newTask->_entry = task_info->_entry;
        newTask->_entryParam = task_info->_entryParam;
        newTask->_stack = task_info->_stack;
        newTask->_stackSize = task_info->_stackSize;

        newTask->_priority = task_info->_priority;

        newTask->_context = _contextFactory->returnContext();
        newTask->_context->init(task_info);

        return newTask->_pid;
    }

    return 0x0;
}

/**
 *
 */
void eGe_TaskManager::startTask(eGIS_TaskId task_id)
{
    eGe_Task *task = (eGe_Task *)task_id;

    eGIS_InterruptManager *intManager = eGIS_KERNEL->getInterruptManager();
    eGIS_IntStatus oldIntStatus = intManager->setIntStatus(INT_OFF);

    _scheduler.addToReadyQueue(task);
    _scheduler.schedule();

    intManager->setIntStatus(oldIntStatus);
}

/**
 *
 */
void eGe_TaskManager::waitTask(eGIS_TaskId task_id, eGIS_Object *obj)
{
    eGe_Task *task = (eGe_Task *)task_id;

    eGIS_InterruptManager *intManager = eGIS_KERNEL->getInterruptManager();
    eGIS_IntStatus oldIntStatus = intManager->setIntStatus(INT_OFF);

    _scheduler.removeFromReadyQueue(task);
    _waitableObjectManager.waitTask(task,obj->_oid);
    _scheduler.schedule();

    intManager->setIntStatus(oldIntStatus);
}

/**
 *
 */
void eGe_TaskManager::wakeUpTasks(eGIS_Object *obj)
{
    eGIS_InterruptManager *intManager = eGIS_KERNEL->getInterruptManager();
    eGIS_IntStatus oldIntStatus = intManager->setIntStatus(INT_OFF);

    eGe_Task *task = _waitableObjectManager.wakeUpTasks(obj->_oid);
    _scheduler.addToReadyQueue(task);
    _scheduler.schedule();

    intManager->setIntStatus(oldIntStatus);
}


/**
 *
 */
eGIS_TaskId eGe_TaskManager::returnCurrentTask()
{
    return (eGIS_TaskId)_scheduler.getCurrentTask();
}

/**
 *
 */
eGIS_TaskPriority eGe_TaskManager::returnPriority(eGIS_TaskId task_id)
{
    eGe_Task *task = (eGe_Task *)task_id;
    return task->_priority;
}
