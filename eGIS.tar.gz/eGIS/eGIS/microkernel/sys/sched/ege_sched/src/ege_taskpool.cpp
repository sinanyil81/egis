#include "../../../../include/egis_kernel.h"
#include "ege_sched.h"

using namespace eGe_Sched;

/**
*
*/
eGe_TaskPool::eGe_TaskPool()
{
    for(uint8_t i=0 ; i<NUM_TASKS ; i++)
    {
        _TASKS[i]._state = TASK_KILLED;
    }
}

/**
 * bosta olan ilk sureci dondurur
 */
eGe_Task *eGe_TaskPool::allocTask()
{

    for(uint8_t i=0 ; i<NUM_TASKS ; i++)
    {
        if(_TASKS[i]._state == TASK_KILLED)
        {
            _TASKS[i]._state = TASK_FREE;
            return &_TASKS[i];
        };
    }

    return 0x0;
}

/**
 * havuza bosalan bir  sureci dondurur 
 */
void eGe_TaskPool::freeTask(eGe_Task *task)
{
    task->_state = TASK_KILLED;
}
