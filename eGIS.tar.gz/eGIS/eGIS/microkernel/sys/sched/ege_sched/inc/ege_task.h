#ifndef eGe_TASK_H_
#define eGe_TASK_H_

class arch_eGIS_TaskContext;

class eGe_Sched::eGe_Task : public eGIS_Object
{
    public :

        void switchTo(eGe_Sched::eGe_Task *nextTask);

    public :

        eGIS_TaskId _pid;
        eGIS_TaskState _state;
        eGIS_TaskPriority _priority;

        eGIS_TaskEntryPoint _entry;
        eGIS_TaskEntryParameter _entryParam;

        eGIS_TaskStack _stack;
        eGIS_TaskStackSize _stackSize;

        arch_eGIS_TaskContext *_context;
};

#endif

