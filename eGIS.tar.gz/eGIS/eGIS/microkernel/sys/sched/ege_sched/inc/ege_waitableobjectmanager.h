#ifndef eGe_WAITABLEOBJECTMANAGER_H_
#define eGe_WAITABLEOBJECTMANAGER_H_

#define MAX_OBJECTS 64

class eGe_Sched::eGe_WaitableObjectManager
{
    public:

        void waitTask(eGe_Sched::eGe_Task *task, eGIS_ObjectId oid);
        eGe_Sched::eGe_Task *wakeUpTasks(eGIS_ObjectId oid);

    protected:

        eGe_Sched::eGe_PriorityQueue _waitingQueues[MAX_OBJECTS];
};

#endif
