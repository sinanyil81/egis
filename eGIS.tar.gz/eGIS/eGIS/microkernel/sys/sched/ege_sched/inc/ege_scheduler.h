#ifndef eGe_SCHEDULER_H_
#define eGe_SCHEDULER_H_

class eGe_Sched::eGe_Scheduler : public eGIS_Object
{
    public:

        eGe_Scheduler();

        void addToReadyQueue(eGe_Task *task);
        void removeFromReadyQueue(eGe_Task *task);
        eGe_Sched::eGe_Task *getCurrentTask();

        void schedule();

    public:

        eGIS_SchedStatus _status;

    protected:

        eGe_Sched::eGe_Task *_currentTask;
        eGe_Sched::eGe_PriorityQueue _readyQueue;
};

#endif
