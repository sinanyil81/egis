#ifndef eGe_SCHED_H_
#define eGe_SCHED_H_

namespace eGe_Sched
{
    class eGe_Task;
    class eGe_PriorityQueue;
    class eGe_TaskPool;
    class eGe_Scheduler;
    class eGe_WaitableObjectManager;
    class eGe_TaskManager;
};

#define NUM_TASKS 64

#include "ege_task.h"
#include "ege_priorityqueue.h"
#include "ege_taskpool.h"
#include "ege_scheduler.h"
#include "ege_waitableobjectmanager.h"
#include "ege_taskmanager.h"

#endif

