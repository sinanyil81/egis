#ifndef eGe_TASKMANAGER_H_
#define eGe_TASKMANAGER_H_

class eGe_Sched::eGe_TaskManager : public eGIS_TaskManager
{
    public:

        eGe_TaskManager(arch_eGIS_TaskContextFactory *contextFactory);

        void init();

        eGIS_TaskId createTask(eGIS_TaskInfo *task_info);
        void startTask(eGIS_TaskId task_id);

        void waitTask(eGIS_TaskId task_id, eGIS_Object *obj);
        void wakeUpTasks(eGIS_Object *obj);

        eGIS_TaskId returnCurrentTask();
        eGIS_TaskPriority returnPriority(eGIS_TaskId task_id);

        void setSchedStatus(eGIS_SchedStatus);

    private:

        eGe_Sched::eGe_Scheduler _scheduler;
        eGe_Sched::eGe_TaskPool _taskPool;
        eGe_Sched::eGe_WaitableObjectManager _waitableObjectManager;
        arch_eGIS_TaskContextFactory *_contextFactory;
};

#endif
