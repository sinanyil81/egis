#ifndef eGe_PRIORITYQUEUE_H_
#define eGe_PRIORITYQUEUE_H_

#define NUM_PRIORITY_LEVEL 8

/**
 * 
 */
class eGe_Sched::eGe_PriorityQueue: public eGIS_Object
{
    public:

        eGe_PriorityQueue();

        void addTask(eGe_Task *task);
        void removeTask(eGe_Task *task);
        eGe_Sched::eGe_Task *returnHighesPriorityTask();

    protected:

        eGe_Sched::eGe_Task *_tasks[NUM_TASKS];

        /// sistemdeki nesnelere ait oncelik bilgilerinin isaretlendigi bit 
        /// tablosu
        uint8_t _ReadyTable[NUM_PRIORITY_LEVEL];
        /// hangi oncelik seviyesinin hazir oldugunu tutan bit maskesi
        uint8_t _ReadyLevel;
};

#endif
