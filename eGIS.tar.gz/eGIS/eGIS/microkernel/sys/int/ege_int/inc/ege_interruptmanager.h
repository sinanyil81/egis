#ifndef eGe_INTERRUPTMANAGER_H_
#define eGe_INTERRUPTMANAGER_H

class arch_eGIS_Interrupt;

class eGe_Int::eGe_InterruptManager : public eGIS_InterruptManager
{
    public:

        eGe_InterruptManager(arch_eGIS_Interrupt *platform);
        virtual ~eGe_InterruptManager();

    public:

        void init();

        eGIS_IntStatus setIntStatus(eGIS_IntStatus);
        eGIS_IntStatus getIntStatus();

        void registerInterruptService(eGIS_InterruptNo interrupt_no,eGIS_InterruptService *service);
        void unregisterInterruptService(eGIS_InterruptNo interrupt_no,eGIS_InterruptService *service);

        void interruptEntry(eGIS_InterruptNo interrupt_no);

    private:

        arch_eGIS_Interrupt *_platform;
        static eGe_Int::eGe_InterruptVector _interruptVector;
        eGIS_IntStatus _intStatus;
};

#endif

