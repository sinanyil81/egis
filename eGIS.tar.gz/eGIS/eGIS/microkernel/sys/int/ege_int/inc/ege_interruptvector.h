#ifndef eGe_INTERRUPTVECTOR_H_
#define eGe_INTERRUPTVECTOR_H_

#define NUM_INTERRUPTS 256

class eGe_Int::eGe_InterruptVector
{
    public:

        static void registerInterrupt(eGIS_InterruptNo interrupt,eGIS_InterruptService *service);
        static void unregisterInterrupt(eGIS_InterruptNo interrupt);
        static eGIS_InterruptService *returnInterruptService(eGIS_InterruptNo interrupt);

    private:

        static eGIS_InterruptService *_interruptVector[NUM_INTERRUPTS];
};

#endif
