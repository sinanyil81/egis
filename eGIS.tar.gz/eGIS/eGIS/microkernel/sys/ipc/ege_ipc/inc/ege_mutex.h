#ifndef eGe_MUTEX_H_
#define eGe_MUTEX_H_

class eGe_Ipc::eGe_Mutex : public eGIS_Mutex
{
    public:

        eGe_Mutex();
        virtual ~eGe_Mutex();

        virtual void init();
        virtual void lock();
        virtual void unlock();

    private:

        int32_t _lockValue;
        uint32_t _waitCount;
};

#endif
