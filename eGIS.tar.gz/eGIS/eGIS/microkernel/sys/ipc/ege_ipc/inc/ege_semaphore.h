#ifndef eGe_IPC_SEMAPHORE_H_
#define eGe_IPC_SEMAPHORE_H_

class eGe_Ipc::eGe_Semaphore : public eGIS_Semaphore
{
    public:

        eGe_Semaphore();
        virtual ~eGe_Semaphore();

        virtual void init(uint32_t init_value);
        virtual void post();
        virtual void wait();

    private:

        int32_t _value;
        uint32_t _waitCount;
};

#endif

