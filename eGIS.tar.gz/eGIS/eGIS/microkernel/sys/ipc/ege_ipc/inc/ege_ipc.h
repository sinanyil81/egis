#ifndef eGe_IPC_H_
#define eGe_IPC_H_

#define MAX_MUTEX_COUNT 32
#define MAX_SEMAPHORE_COUNT 32

namespace eGe_Ipc
{
    class eGe_Mutex;
    class eGe_Semaphore;
    class eGe_IpcManager;
};

#include "ege_mutex.h"
#include "ege_semaphore.h"
#include "ege_ipcmanager.h"

#endif
