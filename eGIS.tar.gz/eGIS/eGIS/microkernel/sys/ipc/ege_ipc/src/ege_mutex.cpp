#include "../../../../include/egis_kernel.h"
#include "ege_ipc.h"

using namespace eGe_Ipc;

/**
 * 
 */
eGe_Mutex::eGe_Mutex()
{
    _lockValue = 1;
    _oid = 0xFF;
    _waitCount = 0;
}

/**
 *
 */
eGe_Mutex::~eGe_Mutex()
{

}

/**
 *
 */
void eGe_Mutex::init()
{

}

/**
 *
 */
void eGe_Mutex::lock()
{
    eGIS_InterruptManager *intManager = eGIS_KERNEL->getInterruptManager();
    eGIS_TaskManager *taskManager = eGIS_KERNEL->getTaskManager();

    eGIS_IntStatus oldIntStatus = intManager->setIntStatus(INT_OFF);

    if(_lockValue !=1)
    {
        eGIS_TaskId pid = taskManager->returnCurrentTask();
        _waitCount++;
        taskManager->waitTask(pid,this);
    }
    else
    {
        _lockValue = 0;
    }

    intManager->setIntStatus(oldIntStatus);
}

/**
 *
 */
void eGe_Mutex::unlock()
{
    eGIS_InterruptManager *intManager = eGIS_KERNEL->getInterruptManager();
    eGIS_TaskManager *taskManager = eGIS_KERNEL->getTaskManager();

    eGIS_IntStatus oldIntStatus = intManager->setIntStatus(INT_OFF);

    if(_lockValue !=1)
    {
        if(--_waitCount == 0)
        {
            _lockValue =1;
        }

        taskManager->wakeUpTasks(this);
    }

    intManager->setIntStatus(oldIntStatus);
}
