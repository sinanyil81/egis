#include "../../../../include/egis_kernel.h"
#include "ege_ipc.h"

using namespace eGe_Ipc;


/**
 * 
 */
eGe_Semaphore::eGe_Semaphore()
{
    _oid = 0xFF;
    _waitCount = 0;
}

/**
 * 
 */
eGe_Semaphore::~eGe_Semaphore()
{

}

/**
 *
 */
void eGe_Semaphore::init(uint32_t init_value)
{
    /* TODO sync gerekebilir*/
    _value = init_value;
}

/**
 *
 */
void eGe_Semaphore::post()
{
    eGIS_InterruptManager *intManager = eGIS_KERNEL->getInterruptManager();
    eGIS_TaskManager *taskManager = eGIS_KERNEL->getTaskManager();

    eGIS_IntStatus oldIntStatus = intManager->setIntStatus(INT_OFF);

    if(_value < 0)
    {
        --_waitCount;
        taskManager->wakeUpTasks(this);
    }
    else
    {
        _value++;
    }

    intManager->setIntStatus(oldIntStatus);
}

/**
 *
 */
void eGe_Semaphore::wait()
{
    eGIS_InterruptManager *intManager = eGIS_KERNEL->getInterruptManager();
    eGIS_TaskManager *taskManager = eGIS_KERNEL->getTaskManager();

    eGIS_IntStatus oldIntStatus = intManager->setIntStatus(INT_OFF);

    if(--_value < 0)
    {
        eGIS_TaskId pid = taskManager->returnCurrentTask();
        _waitCount++;
        taskManager->waitTask(pid,this);
    }

    intManager->setIntStatus(oldIntStatus);
}
