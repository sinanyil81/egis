#include "../../include/egis_kernel.h"

/* sistemde 1 tane bulunan cekirdek nesnesi */
eGIS_Kernel *eGIS_Kernel::_kernel = 0;

/**
 *
 */
eGIS_Kernel::eGIS_Kernel()
{

}

/**
 *
 */
eGIS_Kernel::~eGIS_Kernel()
{

}

/**
 * temel Singleton deseni arayuzu
 */
eGIS_Kernel *eGIS_Kernel::getKernel()
{
    if(eGIS_Kernel::_kernel == 0x0)
    {
        eGIS_Kernel::_kernel = new eGIS_Kernel();
    }
    
    return _kernel;
}

/**
 * 
 */
void eGIS_Kernel::setTaskManager(eGIS_TaskManager *task_manager)
{
    _taskManager = task_manager;
}

/**
 * 
 */
void eGIS_Kernel::setIpcManager(eGIS_IpcManager *ipc_manager)
{
    _ipcManager = ipc_manager;
}

/**
 * 
 */
void eGIS_Kernel::setInterruptManager(eGIS_InterruptManager *interrupt_manager)
{
    _interruptManager = interrupt_manager;
}

/*
 * 
 */
eGIS_TaskManager *eGIS_Kernel::getTaskManager()
{
    return _taskManager;
}

/*
 * 
 */
eGIS_IpcManager *eGIS_Kernel::getIpcManager()
{
    return _ipcManager;
}

/*
 * 
 */
eGIS_InterruptManager *eGIS_Kernel::getInterruptManager()
{
    return _interruptManager;
}
