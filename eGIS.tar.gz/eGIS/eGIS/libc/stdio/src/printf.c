#include "../../../dev/console/inc/console.h"

void printf(char *str)
{
    e_puts(str);
}
