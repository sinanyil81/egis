#ifndef STDLIB_H_
#define STDLIB_H_

#ifdef __cplusplus
extern "C" {
#endif
    
extern char * itoa ( int val, char * buffer, int base);

#ifdef __cplusplus
}   /* extern "C" */
#endif

#endif /*STDLIB_H_*/
