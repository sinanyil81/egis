#include <../../include/sys/types.h>

void *memcpy(void *dest, const void *src, size_t n)
{
    unsigned int i;
    char *source = (char *)src;
    char *destination = (char *)dest;

    for(i = 0; i< n; i++)
    {
        *destination++ = *source++;
    }

    return dest;
}
