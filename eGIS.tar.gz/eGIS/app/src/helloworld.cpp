#include "../../eGIS/microkernel/include/egis_kernel.h"
#include "../../eGIS/microkernel/kapi/c++/inc/eGIS_c++.h"
#include "../../eGIS/libc/include/stdio.h"

#include "sharedresource.h"
#include "producer.h"
#include "consumer.h"

using namespace eGIS;

int App_main()
{
    SharedResource res;
    Producer producer(&res);
    Consumer consumer(&res);

    printf("Hello eGIS...\n");

    printf("Starting Producer...\n");
    producer.start();
    printf("Starting Consumer\n");
    consumer.start();

    for(;;)
    {
        uint32_t x = 0;
        printf("eGIS Running.. \n.");
        x++;
    }

    return 0;
}
