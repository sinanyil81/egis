#include "../../eGIS/microkernel/include/egis_kernel.h"
#include "../../eGIS/microkernel/kapi/c++/inc/eGIS_c++.h"
#include "../../eGIS/libc/include/stdio.h"

#include "sharedresource.h"
#include "producer.h"

using namespace eGIS;

/**
 *
 */
Producer::Producer(SharedResource *sharedResource) : e_Thread(30)
{
    _sharedResource = sharedResource;
}

/**
 *
 */
Producer::~Producer()
{

}

/**
 *
 */
void Producer::entry()
{
    while(1)
    {
        printf("Producer \n");
        _sharedResource->produce();
    }
}
