#ifndef PRODUCER_H_
#define PRODUCER_H_

class Producer : public eGIS::e_Thread
{
    public:

        Producer(SharedResource *sharedResource);
        virtual ~Producer();

        virtual void entry();

    private:

        SharedResource *_sharedResource;
};

#endif

