#include "../../eGIS/microkernel/include/egis_kernel.h"
#include "../../eGIS/microkernel/kapi/c++/inc/eGIS_c++.h"
#include "../../eGIS/libc/include/stdio.h"

#include "sharedresource.h"
#include "consumer.h"

using namespace eGIS;

/**
 *
 */
Consumer::Consumer(SharedResource *sharedResource) :e_Thread(31)
{
    _sharedResource = sharedResource;
}

/**
 *
 */
Consumer::~Consumer()
{

}

/**
 *
 */
void Consumer::entry()
{
    while(1)
    {
        printf("Consumer \n");
        _sharedResource->consume();
    }
}
