#ifndef CONSUMER_H_
#define CONSUMER_H_

class Consumer : public eGIS::e_Thread
{
    public:

        Consumer(SharedResource *sharedResource);
        virtual ~Consumer();

        void entry();

    private:

        SharedResource *_sharedResource;
};

#endif
