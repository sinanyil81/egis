#!/bin/bash
#TOOL='LINUX'
TOOLSET='LINUX'
export TOOLSET=LINUX
echo $TOOLSET
echo "system is cleaning"
make -f system.mak clean
clear
make -f system.mak
