#define VIDEO_ADRESS    0xb8000

static char *videoAddr = (char *)VIDEO_ADRESS ;
static unsigned int offset = 0;
static unsigned int x = 0;

/**
 *
 */
void e_clear()
{
    unsigned int i;

    for(i=0; i<(80*25); i++)
    {
        videoAddr[i*2]      = ' ';
        videoAddr[i*2 + 1]  = 0x1b ;
    }

    x = offset = 0;
}

/**
 *
 */
 void e_putc(char c)
{
    if(x >=80)
    {
        x=0 ;
        offset += 80 ;
    }

    if(offset >= (80*25))
    {
        e_clear();
    }

    videoAddr[(offset + x)*2] = c;

    x++ ;
}

/**
 *
 */
void e_puts(char *str)
{
    char ch;

    while((ch = *str++) != '\0')
    {
        switch(ch)
        {
            case '\n':
                x = 0;
                offset += 80;

                if(offset >= 80*25)
                {
                    e_clear();
                }

                break;

            default:
                e_putc(ch) ;
                break;
        };

    }
}
