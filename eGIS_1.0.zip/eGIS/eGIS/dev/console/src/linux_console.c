#include <stdio.h>

/**
 *
 */
void e_clear()
{
    unsigned int i;

    for(i=0; i<(80*25); i++)
    {
        putchar(' ');
    }
}

/**
 *
 */
void e_putc(char c)
{
    putchar(c);
}

/**
 *
 */
void e_puts(char *str)
{
    puts(str);
}
