#include "../../include/egis_kernel.h"

/* sistemde 1 tane bulunan cekirdek nesnesi */
eGIS_Kernel *eGIS_Kernel::_kernel = 0;

/**
 *
 */
eGIS_Kernel::eGIS_Kernel() {}

/**
 *
 */
eGIS_Kernel::~eGIS_Kernel() {
}

/**
 * temel Singleton deseni arayuzu
 */
eGIS_Kernel *eGIS_Kernel::getKernel() {
    if ( eGIS_Kernel::_kernel == 0x0 ) {
        eGIS_Kernel::_kernel = new eGIS_Kernel();
    }

    return _kernel;
}
