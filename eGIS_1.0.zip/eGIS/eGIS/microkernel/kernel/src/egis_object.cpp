#include "../../include/egis_kernel.h"

/**
 * ilkleyici metod
 */
eGIS_Object::eGIS_Object()
{

}

/**
 * sonlandirici metod
 */
eGIS_Object::~eGIS_Object()
{

}

/**
 *
 */
void* eGIS_Object::operator new (uint32_t size)
{
    return kmalloc(size);
}
    
/**
 * 
 */
void* eGIS_Object::operator new[] (uint32_t size)
{
    return kmalloc(size);
}
    
/**
 * 
 */
void eGIS_Object::operator delete (void *ptr)
{
    return kfree(ptr);
}

/**
 * 
 */
void eGIS_Object::operator delete[] (void *ptr)
{
    return kfree(ptr);
}
