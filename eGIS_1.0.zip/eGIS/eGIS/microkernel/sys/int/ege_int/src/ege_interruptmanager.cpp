#include "../../../../include/egis_kernel.h"
#include "ege_int.h"

using namespace eGe_Int;

eGe_InterruptVector eGe_InterruptManager::_interruptVector;

/**
 * ilkleyici metod
 */
eGe_InterruptManager::eGe_InterruptManager()
{
    _intStatus = INT_OFF;
}

/**
 * sonlandirici metod
 */
eGe_InterruptManager::~eGe_InterruptManager()
{

}

/** 
 * kesme sistemini ilkler
 */
void eGe_InterruptManager::init()
{
    _platform.init();
} 

/**
 * 
 */ 
eGIS_IntStatus eGe_InterruptManager::setIntStatus(eGIS_IntStatus newStat)
{
    eGIS_IntStatus oldStat = _intStatus;

    if(newStat == oldStat)
    {
        return oldStat;
    }
    else if(newStat == INT_ON)
    {
        _intStatus = INT_ON;
        _platform.enableInts();
    }
    else 
    {
        _platform.disableInts();
        _intStatus = INT_OFF;
    }

    return oldStat;
}

/**
 * 
 */
eGIS_IntStatus eGe_InterruptManager::getIntStatus()
{
    return _intStatus;
}

/**
 * 
 */
void eGe_InterruptManager::registerInterruptService(eGIS_InterruptNo interrupt_no,eGIS_InterruptHandler service)
{
    eGIS_IntStatus oldStat = setIntStatus(INT_OFF);

    _interruptVector.registerInterrupt(interrupt_no,service);
    _platform.registerHandler(interrupt_no);

    setIntStatus(oldStat);
}

/**
 * 
 */
void eGe_InterruptManager::unregisterInterruptService(eGIS_InterruptNo interrupt_no,eGIS_InterruptHandler service)
{
    eGIS_IntStatus oldStat = setIntStatus(INT_OFF);

    _interruptVector.unregisterInterrupt(interrupt_no);

    setIntStatus(oldStat);
}

/**
 * 
 */
void eGe_InterruptManager::interruptEntry(eGIS_InterruptNo interrupt_no)
{
    eGIS_InterruptHandler service = _interruptVector.returnInterruptService(interrupt_no);

    if(service)
    {
        service(0);
    }
}
