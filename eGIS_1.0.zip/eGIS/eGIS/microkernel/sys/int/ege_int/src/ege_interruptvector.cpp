#include "../../../../include/egis_kernel.h"
#include "ege_int.h"

using namespace eGe_Int;

eGIS_InterruptHandler eGe_InterruptVector::_interruptVector[NUM_INTERRUPTS] = {0};

/**
 * 
 */
void eGe_InterruptVector::registerInterrupt(eGIS_InterruptNo interrupt,eGIS_InterruptHandler service) {
    _interruptVector[interrupt] = service;
}

/**
 * 
 */
void eGe_InterruptVector::unregisterInterrupt(eGIS_InterruptNo interrupt) {
    _interruptVector[interrupt] = 0x0;
}

/**
 * 
 */
eGIS_InterruptHandler eGe_InterruptVector::returnInterruptService(eGIS_InterruptNo interrupt) {
            return _interruptVector[interrupt];
}

extern "C" void InterruptEntry(uint32_t int_no) {
    if (eGe_InterruptVector::returnInterruptService(int_no))
        (eGe_InterruptVector::returnInterruptService(int_no))(0);
}

