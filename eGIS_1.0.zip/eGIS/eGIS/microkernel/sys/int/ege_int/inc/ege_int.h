#ifndef eGe_INT_H_
#define eGe_INT_H_

namespace eGe_Int
{
    class eGe_InterruptManager;
    class eGe_InterruptVector;
};

#include "ege_interruptmanager.h"
#include "ege_interruptvector.h"

#endif

