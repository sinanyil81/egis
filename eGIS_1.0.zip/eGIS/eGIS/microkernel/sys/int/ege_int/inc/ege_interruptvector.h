#ifndef eGe_INTERRUPTVECTOR_H_
#define eGe_INTERRUPTVECTOR_H_

#define NUM_INTERRUPTS 256

class eGe_Int::eGe_InterruptVector {
public:

    static void registerInterrupt(eGIS_InterruptNo interrupt,eGIS_InterruptHandler service);
    static void unregisterInterrupt(eGIS_InterruptNo interrupt);
    static eGIS_InterruptHandler returnInterruptService(eGIS_InterruptNo interrupt);

private:

    static eGIS_InterruptHandler _interruptVector[NUM_INTERRUPTS];
};

#endif
