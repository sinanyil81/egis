#ifndef eGe_TASKMANAGER_H_
#define eGe_TASKMANAGER_H_

class eGe_Sched::eGe_TaskManager : public eGIS_Object {
public:

    eGe_TaskManager();

    void init();

    eGIS_TaskId createTask(eGIS_TaskInfo *task_info);
    void startTask(eGIS_TaskId task_id);

    void waitTask(eGIS_TaskId task_id);
    void wakeUpTask(eGIS_TaskId task_id);

    eGIS_TaskId returnCurrentTask();
    eGIS_TaskPriority returnPriority(eGIS_TaskId task_id);
    eGIS_TaskId returnTask(eGIS_TaskPriority priority);

    void schedule();
    void setSchedStatus(eGIS_SchedStatus);

private:

    eGe_Sched::eGe_Scheduler _scheduler;
    eGe_Sched::eGe_TaskPool _taskPool;
    arch_eGIS_TaskContextFactory _contextFactory;
};

#endif
