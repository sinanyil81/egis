#ifndef eGe_TASKPOOL_H_
#define eGe_TASKPOOL_H_

/**
 * sistemdeki surecleri tutar
 */
class eGe_Sched::eGe_TaskPool : public eGIS_Object {
public:

    eGe_TaskPool();

    eGe_Task *allocTask(uint8_t);
    eGe_Task *getTask(eGIS_TaskPriority priority);
    void freeTask(eGe_Task *task);

private:

    eGe_Task _TASKS[NUM_TASKS];
};

#endif

