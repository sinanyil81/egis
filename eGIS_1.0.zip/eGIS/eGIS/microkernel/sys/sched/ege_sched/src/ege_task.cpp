#include "../../../../include/egis_kernel.h"
#include "ege_sched.h"

using namespace eGe_Sched;

/**
 *
 */
void eGe_Task::switchTo(eGe_Task *nextTask)
{
    _context->switchTo(nextTask->_context);
}

