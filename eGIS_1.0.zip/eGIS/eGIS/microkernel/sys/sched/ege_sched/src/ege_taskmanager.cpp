#include "../../../../include/egis_kernel.h"
#include "ege_sched.h"

using namespace eGe_Sched;

/**
 *
 */
eGe_TaskManager::eGe_TaskManager() {
    _scheduler.setTaskManager(this);
}

/**
 *
 */
void eGe_TaskManager::init() {}

/**
 *
 *
 */

void eGe_TaskManager::schedule() {
    _scheduler.schedule();
}

/**
 *
 */
void eGe_TaskManager::setSchedStatus(eGIS_SchedStatus status) {
    _scheduler._status = status;
}

/**
 *
 */
eGIS_TaskId eGe_TaskManager::createTask(eGIS_TaskInfo *task_info) {
    /* surec havuzundan bir surec al */
    eGe_Task *newTask = _taskPool.allocTask(task_info->_priority);

    if(newTask) {
        /* surec ozelliklerini ilkle */
        newTask->_pid = (eGIS_TaskId)newTask;

        newTask->_entry = task_info->_entry;
        newTask->_entryParam = task_info->_entryParam;
        newTask->_stack = task_info->_stack;
        newTask->_stackSize = task_info->_stackSize;

        newTask->_priority = task_info->_priority;

        newTask->_context = _contextFactory.returnContext();
        newTask->_context->init(task_info);

        return newTask->_pid;
    }

    return 0x0;
}

/**
 *
 */
void eGe_TaskManager::startTask(eGIS_TaskId task_id) {
    eGe_Task *task = (eGe_Task *)task_id;
    _scheduler.addToReadyQueue(task);
}

/**
 *
 */
void eGe_TaskManager::waitTask(eGIS_TaskId task_id) {
    eGe_Task *task = (eGe_Task *)task_id;

    _scheduler.removeFromReadyQueue(task);
//     _scheduler.schedule();
}

/**
 *
 */
void eGe_TaskManager::wakeUpTask(eGIS_TaskId task_id) {

    _scheduler.addToReadyQueue((eGe_Task *)task_id);
//     _scheduler.schedule();

}


/**
 *
 */
eGIS_TaskId eGe_TaskManager::returnCurrentTask() {
    return (eGIS_TaskId)_scheduler.getCurrentTask();
}

/**
*
*/
eGIS_TaskPriority eGe_TaskManager::returnPriority(eGIS_TaskId task_id) {
    eGe_Task *task = (eGe_Task *)task_id;
    return task->_priority;
}


/**
*
*/
eGIS_TaskId eGe_TaskManager::returnTask(eGIS_TaskPriority priority) {
    return (eGIS_TaskId)_taskPool.getTask(priority);
}
