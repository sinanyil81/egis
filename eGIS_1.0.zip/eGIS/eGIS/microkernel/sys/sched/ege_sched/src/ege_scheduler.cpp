#include "../../../../include/egis_kernel.h"
#include "ege_sched.h"

using namespace eGe_Sched;

/**
 *
 */
eGe_Scheduler::eGe_Scheduler() {
    _currentTask = 0x0;
    _status = SCHED_OFF;
}

void eGe_Scheduler::setTaskManager(eGe_TaskManager *taskManager) {
    _taskManager=taskManager;
}

/**
 *
 */
void eGe_Scheduler::addToReadyQueue(eGe_Task *task) {
    task->_state = TASK_READY;
    _readyQueue.addTask(task);
}

/**
 *
 */
void eGe_Scheduler::removeFromReadyQueue(eGe_Task *task) {
    _readyQueue.removeTask(task);
    task->_state = TASK_STOPPED;
}

/**
 *
 */
eGe_Task *eGe_Scheduler::getCurrentTask() {
    return _currentTask;
}

/**
 *
 */
void eGe_Scheduler::schedule() {
    if(_status != SCHED_ON) {
        return;
    }

    //     eGe_Task *taskToRun = _readyQueue.returnHighesPriorityTask();

    uint8_t hpt_id=_readyQueue.returnHighesPriorityTask();
    eGe_Task *taskToRun = (eGe_Task *)_taskManager->returnTask(hpt_id);
    /*
        eGIS_TaskPriority pr = taskToRun->_priority;*/

    /* ancak yeni bir surece gecis yap. */
    if(_currentTask != taskToRun) {
        /* o an calisan bir task var mi? */
        if(!_currentTask) {
            /* yeni calisan sureci sakla */
            _currentTask = taskToRun;

            /* yoksa yeni task kendi kendine atlasin */
            taskToRun->switchTo(taskToRun);
        } else {
            /* su anki surec */
            eGe_Task *runningTask = _currentTask;

            /* yeni calisan sureci sakla */
            _currentTask = taskToRun;

            /* eski surec yeni surece gecis yapsin */
            runningTask->switchTo(taskToRun);

        }
    }
}
