#include "../../../../include/egis_kernel.h"
#include "ege_sched.h"

using namespace eGe_Sched;

/**
*
*/
eGe_TaskPool::eGe_TaskPool() {
    for(uint8_t i=0 ; i<NUM_TASKS ; i++) {
        _TASKS[i]._state = TASK_KILLED;
    }
}

/**
 * bosta olan ilk sureci dondurur
 */
eGe_Task *eGe_TaskPool::allocTask(uint8_t priority) {
    
    if (_TASKS[priority]._state == TASK_KILLED) {
        _TASKS[priority]._state=TASK_FREE;
        return &_TASKS[priority];
    }

    return 0x0;
}

/**
 *priority degeri verilen taskı döndürür
 */
eGe_Task *eGe_TaskPool::getTask(eGIS_TaskPriority priority) {
    return &_TASKS[priority];
}

/**
 * havuza bosalan bir  sureci dondurur 
 */
void eGe_TaskPool::freeTask(eGe_Task *task) {
    task->_state = TASK_KILLED;
}
