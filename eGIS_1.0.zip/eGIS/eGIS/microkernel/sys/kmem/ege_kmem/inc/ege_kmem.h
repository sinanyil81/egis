#ifndef eGe_KMEM_H_
#define eGe_KMEM_H_

#include "../../../../include/egis_kernel.h"

namespace eGe_Memory {
class eGe_Kmem;
struct eGe_memNode;
};

struct eGe_memNode {
    eGe_memNode *prev;
    eGe_memNode *next;
    uint8_t state;
    uint32_t size;
    void *ptr;
};

typedef struct eGe_memNode memNode;

class eGe_Memory::eGe_Kmem {
public:

    eGe_Kmem();
    eGe_Kmem(uint8_t *memory,uint32_t size);
    ~eGe_Kmem();

    void setMem(uint8_t *memory,uint32_t size);
    void *allocMem(uint32_t size);
    void freeMem(void *ptr);

private:

    void split(uint32_t address,uint32_t size);
    void merge(memNode *block);

    //private olacak
protected:

    uint8_t *_memory;
    uint32_t _size;

protected:
    memNode startNode;

};

#endif
