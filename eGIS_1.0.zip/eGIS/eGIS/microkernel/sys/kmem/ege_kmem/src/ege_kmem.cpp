#include "../inc/ege_kmem.h"
#include <stdio.h>

#define FREE 0
#define USED 1

using namespace eGe_Memory;

/**
 *
 */
eGe_Kmem::eGe_Kmem(uint8_t *memory,uint32_t size) {
    _memory=memory;
    _size=size;

    startNode.ptr=memory+sizeof(memNode);
    startNode.prev=0;
    startNode.next=0;
    startNode.state=FREE;

    startNode.size=_size-sizeof(memNode);
}

/**
 *
 */
eGe_Kmem::eGe_Kmem() {}

/**
 *
 */
eGe_Kmem::~eGe_Kmem() {}

/**
*
*/
void eGe_Kmem::setMem(uint8_t *memory,uint32_t size) {
    _memory=memory;
    _size=size;

    startNode.ptr=memory+sizeof(memNode);
    startNode.prev=0;
    startNode.next=0;
    startNode.state=FREE;

    startNode.size=_size-sizeof(memNode);
}

/**
 * TODO : mutexle koruma ekle
 */
void *eGe_Kmem::allocMem(uint32_t size) {
    if (!size)
        return 0x0;

    memNode *node=&startNode;
    while( node->next ) {
        if((node->size >= size) && (node->state==FREE)) {
            split((uint32_t)&(*node),size);
            return (void *)node->ptr;
        }
        node=node->next;
    }

    if((node->size >= size) && (node->state==FREE)) {
        split((uint32_t)&(*node),size);
        return (void *)node->ptr;
    }

    return 0x0;
}

/**
 *
 */
void eGe_Kmem::split(uint32_t addres,uint32_t size) {
    /* o anki bos blok tum istegimizi karsilayabilecek buyuklukte mi yoksa
    * daha mi buyuk ? */

    memNode *node=(memNode *)addres;
    if(node->size >= size + sizeof(memNode)) {
        /* blok daha da buyuk*/
        memNode *oldNext;
        memNode *oldPrev;
        uint32_t oldSize;

        oldNext = node->next;
        oldPrev  = node->prev;
        oldSize= node->size;

        memNode *newNode = (memNode *) (((uint32_t)node->ptr) + size);

        node->next = newNode;
        node->prev = oldPrev;
        node->state = USED;
        node->size = size;

        newNode->next = oldNext;
        newNode->prev = node;
        newNode->state = FREE;
        newNode->size = oldSize - size - sizeof(memNode);
        newNode->ptr =(void *)((uint32_t)newNode + sizeof(memNode));

    } else {
        /* blok tam istedigimiz boyutta */

        node->state = USED;
    }

    return;
}

/**
 * 
 */
void eGe_Kmem::merge(memNode *block) {
    if(!block->prev) {
        if(block->next==0) {
            block->state = FREE;
        } else if(block->next->state == USED) {
            block->state = FREE;
        } else if(block->next->state == FREE) {
            block->state = FREE;
            block->size = block->size + block->next->size + sizeof(memNode);
            block->next = block->next->next;
            block->next->next->prev = block;
        }
    } else if (!block->next->next) {
        if(block->prev->state == USED) {
            block->state = FREE;
        } else if(block->prev->state == FREE) {
            block->prev->size = block->prev->size + block->size + sizeof(memNode);
            block->prev->next = block->next;
        }
    }
    //node ortada
    else if ( (block->prev->state == USED) && (block->next->state == USED) ) {
        block->state = FREE;
    } else if ( (block->prev->state == USED) && (block->next->state == FREE) ) {
        block->state = FREE;
        block->size  = block->size + block->next->size + sizeof(memNode);
        block->next  = block->next->next;

        if(block->next->next) {
            block->next->next->prev = block;
        }
    } else if ( (block->prev->state == FREE) && (block->next->state == USED) ) {
        block->prev->size = block->prev->size + block->size + sizeof(memNode);
        block->prev->next = block->next;
        block->next->prev = block->prev;
    } else if ( (block->prev->state == FREE) && (block->next->state == FREE) ) {
        block->prev->size =  block->prev->size + block->size + (sizeof(memNode)<<1) + block->next->size;
        block->prev->next = block->next->next;
        if(block->next->next) {
            block->next->next->prev = block->prev;
        }
    }
    return;
}

/**
 * 
 */
void eGe_Kmem::freeMem(void *ptr) {
    if(ptr == 0x0) {
        return;
    }

    /* adres RAM sinirlarini asiyor mu? */
    if( (ptr >= (void*)&this->_memory[this->_size]) ||
            (ptr <  (void *)(((uint32_t)&this->_memory[0])+sizeof(memNode)))) {
        return;
    }

    memNode *freeNode=(memNode *)(((uint32_t)ptr)-sizeof(memNode));
/*
    int ctrl1,ctrl2,ctrl3,ctrl4,ctrl5;
    ctrl1=(freeNode->state != USED) ? 1 :0;
    ctrl2=(((uint32_t)freeNode->prev!=(uint32_t)&startNode)&&((uint32_t)freeNode->prev >= (uint32_t)freeNode)) ? 1 : 0;
    ctrl3=((uint32_t)freeNode->next >= (uint32_t)(((uint32_t)this->_memory)+this->_size)) ? 1 : 0;
    ctrl4=(freeNode->size >= this->_size) ? 1 : 0;
    ctrl5=(freeNode->size == 0) ? 1 : 0;*/

    if ((freeNode->state != USED)||
            (((uint32_t)freeNode->prev!=(uint32_t)&startNode)&&((uint32_t)freeNode->prev >= (uint32_t)freeNode))||
            ((uint32_t)freeNode->next >= (uint32_t)(((uint32_t)this->_memory)+this->_size))||
            (freeNode->size >= this->_size)||
            (freeNode->size == 0)) {
        return;
    }

    merge(freeNode);
}
