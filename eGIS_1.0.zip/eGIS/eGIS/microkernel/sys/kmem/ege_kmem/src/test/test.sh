#!/bin/bash
make
#clear
./mem_test
