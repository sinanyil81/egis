#define TEST

#include <stdio.h>
#include <stdlib.h>

#include "../../inc/ege_kmem.h"

using namespace eGe_Memory;

class kmem_Test : public eGe_Kmem {
public:

    memNode getStart() {
        return startNode;
    }
    void memsizeYaz() {
        printf("memory %p size %d\n",_memory,_size);
    }
};

void allocationTest(kmem_Test &kmem);
void constructorTest(kmem_Test &kmem,uint8_t *a);
void freeMemTest(kmem_Test &kmem);

int main() {
    uint8_t *a=(uint8_t *)malloc(100);

    kmem_Test kmem;

    constructorTest(kmem,a);
    //allocationTest(kmem);
    freeMemTest(kmem);

}

void constructorTest(kmem_Test &kmem,uint8_t *a) {
    printf("\n---------------------constructor test----------------------------\n");
    kmem.setMem(a,200);
    kmem.memsizeYaz();
    printf("start Node pointer is %p start size %d\n",kmem.getStart().ptr,kmem.getStart().size);
    printf("--------------------------------------------------------------------\n\n");
}

void allocationTest(kmem_Test &kmem) {
    printf("----------------------allocation test-------------------------------\n");
    void *ptr;
    ptr=kmem.allocMem(80);
    printf("first allocation is %s\n",(ptr==kmem.getStart().ptr) ? "OK" : "FAILED");
    printf("---------------------------------------------------------------------\n\n");
    ptr=kmem.allocMem(2);
    printf("second allocation is %s\n",(ptr==(void *)(((uint32_t)(kmem.getStart().ptr))+100)) ? "OK" : "FAILED");
    printf("---------------------------------------------------------------------\n\n");
    ptr=kmem.allocMem(1);
    printf("third allocation is %s\n",(ptr==(void *)(((uint32_t)(kmem.getStart().ptr))+122)) ? "OK" : "FAILED");
    printf("---------------------------------------------------------------------\n\n");
    ptr=kmem.allocMem(2);
    printf("fourth allocation is %s\n",(ptr==(void *)(((uint32_t)(kmem.getStart().ptr))+143)) ? "OK" : "FAILED");
    printf("---------------------------------------------------------------------\n\n");
    ptr=kmem.allocMem(1);
    printf("fifth allocation is %s\n",(ptr==(void *)(((uint32_t)(kmem.getStart().ptr))+165)) ? "OK" : "FAILED");
    printf("---------------------------------------------------------------------\n\n");
    ptr=kmem.allocMem(1);
    printf("fifth allocation is %s because fifth allocation size is %d\n",(ptr==(void *)(0)) ? "OK" : "FAILED",kmem.getStart().next->next->next->next->size);
    printf("---------------------------------------------------------------------\n\n");

}

void freeMemTest(kmem_Test &kmem) {
    void *ptr1, *ptr2, *ptr3;
    ptr1=kmem.allocMem(10);
    ptr2=kmem.allocMem(10);
    ptr3=kmem.allocMem(10);

    kmem.freeMem(ptr3);
    printf("first freeMem test is %s\n",(((memNode *)(((uint32_t)ptr3)-sizeof(memNode)))->state) ? "FAILED" :"OK");
    printf("first freeMem test is %s\n",(((memNode *)(((uint32_t)ptr2)-sizeof(memNode)))->state) ? "OK" :"FAILED");
    kmem.freeMem(ptr2);
    printf("first freeMem test is %s\n",(((memNode *)(((uint32_t)ptr2)-sizeof(memNode)))->state) ? "FAILED" :"OK");
    
}
