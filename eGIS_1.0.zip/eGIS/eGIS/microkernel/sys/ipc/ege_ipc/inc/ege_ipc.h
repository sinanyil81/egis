#ifndef eGe_IPC_H_
#define eGe_IPC_H_

#define MAX_MUTEX_COUNT 32
#define MAX_SEMAPHORE_COUNT 32
#define MAX_QUEUE_COUNT 2

namespace eGe_Ipc {
class eGe_Event;
class eGe_Semaphore;
class eGe_Mutex;
class eGe_Queue;
class eGe_PriorityQueueIpc;
class eGe_IpcManager;
};

#define ENTER_CRITICAL_SECTION(){eGIS_InterruptManager intManager = eGIS_INTERRUPT_MANAGER;\
    eGIS_IntStatus oldIntStatus = intManager.setIntStatus(INT_OFF);}

#define EXIT_CRITICAL_SECTION(){intManager.setIntStatus(oldIntStatus);}

#include "ege_event.h"
#include "ege_semaphore.h"
#include "ege_mutex.h"
#include "ege_queue.h"
#include "pq.h"
#include "ege_ipcmanager.h"

#endif
