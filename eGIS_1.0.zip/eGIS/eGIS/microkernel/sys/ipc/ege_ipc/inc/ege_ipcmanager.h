#ifndef eGe_IPCMANAGER_H_
#define eGe_IPCMANAGER_H_

class eGe_Ipc::eGe_IpcManager {
public:

    eGe_IpcManager();
    
    eGIS_Mutex *allocMutex();
    eGIS_Semaphore *allocSemaphore();
    eGIS_Queue *allocQueue();
    void freeMutex(eGIS_Mutex *);
    void freeSemaphore(eGIS_Semaphore *);
    void freeQueue(eGIS_Queue *);
    
protected:

    eGe_Ipc::eGe_Mutex _MUTEXES[MAX_MUTEX_COUNT];
    eGe_Ipc::eGe_Semaphore _SEMAPHORES[MAX_SEMAPHORE_COUNT];
    eGe_Ipc::eGe_Queue _QUEUES[MAX_QUEUE_COUNT];
};

#endif
