#ifndef eGe_IPC_SEMAPHORE_H_
#define eGe_IPC_SEMAPHORE_H_

class eGe_Ipc::eGe_Semaphore : public eGe_Event {
public:
    eGe_Semaphore();
    ~eGe_Semaphore();

    void init ( uint32_t init_value );
    void post();
    void wait();

    //     private yapilacak
protected:

    int32_t _value;
};

#endif

