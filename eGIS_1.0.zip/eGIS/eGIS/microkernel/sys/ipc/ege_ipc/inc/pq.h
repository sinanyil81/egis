#ifndef PQ_H
#define PQ_H

#define NUM_PRIORITY_LEVEL 8

class eGe_Ipc::eGe_PriorityQueueIpc {
public:

    eGe_PriorityQueueIpc();

    void priorityQueueListInit(eGe_Event *event);
    void addTask(eGe_Event *event, uint8_t taskID);
    uint8_t removeTask(eGe_Event *event);
    uint8_t returnHighesPriorityTask(eGe_Event *event);

};

#endif
