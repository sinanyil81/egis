#ifndef eGe_EVENT_H
#define eGe_EVENT_H

#define MAX_TASK_ID 63
#define MAX_TABLE_SIZE  MAX_TASK_ID/8+1

#define MAX_QUEUE_SIZE 8

class eGe_Ipc::eGe_Event : public eGIS_Object {
public:

    eGe_Event();
    ~eGe_Event();

protected:
    void eventWaitListInit();
    uint8_t eventTaskReady();
    void eventTaskWait();

public:

    uint8_t eventGrup;
    uint8_t eventTable[MAX_TABLE_SIZE];
};

#endif
