#ifndef eGe_QUEUE_H
#define eGe_QUEUE_H

class eGe_Ipc::eGe_Queue : public eGe_Event {
public:
    eGe_Queue();
    ~eGe_Queue();

    void *wait();
    uint8_t post(void *msg);

private:
    uint8_t _head;
    uint8_t _tail;
    uint8_t _entry;
    void *_messageTable[MAX_QUEUE_SIZE];
};

#endif
