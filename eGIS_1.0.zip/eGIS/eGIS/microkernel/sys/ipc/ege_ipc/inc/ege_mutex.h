#ifndef eGe_MUTEX_H_
#define eGe_MUTEX_H_

class eGe_Ipc::eGe_Mutex : public eGe_Event {
public:

    eGe_Mutex();
    ~eGe_Mutex();

    void init();
    void lock();
    void unlock();
    // private yapilacak
protected :

    int32_t _lockValue;
    int8_t _ownerTaskID;
};

#endif
