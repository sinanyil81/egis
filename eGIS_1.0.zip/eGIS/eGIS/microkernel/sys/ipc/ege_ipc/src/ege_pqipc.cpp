#include "../../../../include/egis_kernel.h"
#include "../inc/ege_ipc.h"
using namespace eGe_Ipc;

/* seviye durum bitleri ve o seviyedeki nesnenin bitlerinin
 * yardimi ile,nesnenin gercek onceligini bulunmasini sag-
 * layan degerleri iceren tablodur.
 */
static const uint8_t UnmapTbl[] = {
    0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
};


/* oncelik 8 bitle ifade ediliyor. 64 nesne olacagi icin 6 bit
 * yeterli. 6 bitin sagdan 3 biti oncelik seviyesi icindeki
 * nesne numarasini tutuyor ( 1 seviyede 8 surec var ). Diger 3
 * bit ise oncelik seviyesini tutuyor.
 *
 *  xxss syyy ( 8 bit oncelik )
 *    || ||||___
 *    || |||____  Nesne Yeri
 *    || ||_____
 *    || |__
 *    ||____  Oncelik seviyesi
 *    |_____
 */

#define PRIORITY_LEVEL_MASK 0x38

#define PRIORITY_BIT_MASK 0x07

eGe_PriorityQueueIpc::eGe_PriorityQueueIpc() {}

void eGe_PriorityQueueIpc::priorityQueueListInit(eGe_Event *event) {
    event->eventGrup=0x00;
    for ( int i=0; i<MAX_TABLE_SIZE; ++i) {
        event->eventTable[i]=0x00;
    }
}

void eGe_PriorityQueueIpc::addTask(eGe_Event *event, uint8_t taskID) {
    uint8_t priorityLevel;
    uint8_t priorityBits;

    priorityLevel = (taskID & PRIORITY_LEVEL_MASK)>>3;
    priorityBits = taskID & PRIORITY_BIT_MASK;

    event->eventTable[priorityLevel] |= 0x01 << priorityBits;
    event->eventGrup |= 0x01 << priorityLevel;
}

/**
 * surec kuyrugundan bir surec cikartir ve takip yapilan
 * ilgili bitleri 0'lar.
 */
uint8_t eGe_PriorityQueueIpc::removeTask(eGe_Event *event) {

    uint8_t x;
    uint8_t y;
    uint8_t px;
    uint8_t py;

    uint8_t priority;

    y=UnmapTbl[event->eventGrup];
    py=(uint8_t)(1<<y);
    x=UnmapTbl[event->eventTable[y]];
    px=(uint8_t)(1<<x);

    priority=(uint8_t)((y<<3)+x);
    if (!(event->eventTable[y] &= ~px))
        event->eventGrup &= ~py;

    return priority;

}

/**
 * oncelik seviyelerini inceleyerek, en oncelikli nesneyi dondurur
 */
uint8_t eGe_PriorityQueueIpc::returnHighesPriorityTask(eGe_Event *event) {
    uint8_t priorityLevel;
    uint8_t priorityBits;

    priorityLevel = UnmapTbl[event->eventGrup];
    priorityBits = event->eventTable[priorityLevel];

    return (uint8_t)((priorityLevel << 3) | (UnmapTbl[priorityBits]));
}

