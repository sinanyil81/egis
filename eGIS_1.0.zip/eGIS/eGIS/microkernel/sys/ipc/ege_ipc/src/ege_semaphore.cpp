#include "../../../../include/egis_kernel.h"
#include "../inc/ege_ipc.h"
using namespace eGe_Ipc;

eGe_Semaphore::eGe_Semaphore() {
    eventWaitListInit();
}

eGe_Semaphore::~eGe_Semaphore() {}

void eGe_Semaphore::init(uint32_t init_value) {
    _value=init_value;
}

void eGe_Semaphore::post() {
    //operating system enter critical
    eGIS_IntStatus oldIntStatus = eGIS_INTERRUPT_MANAGER.setIntStatus(INT_OFF);

    //value göre kontrol çünkü sisteme (event_grup a task) bir task girmden artış olabilir.
    uint8_t rdy_run_taskID;
    if (eventGrup) {
        //task id sahip task waitten ready e geçecek
        rdy_run_taskID=eventTaskReady();
        //TASK ile ilgili işlem (sched)
        eGIS_TASK_MANAGER.schedule();
    } else
        _value++;

    //operating system exit critical
    eGIS_INTERRUPT_MANAGER.setIntStatus(oldIntStatus);
}

void eGe_Semaphore::wait() {

    //operating system enter critical
    eGIS_IntStatus oldIntStatus = eGIS_INTERRUPT_MANAGER.setIntStatus(INT_OFF);

    //value nin (-) olma ihtimali yok
    if (_value) {
        --_value;
    } else {
        eventTaskWait();
        //TASK ile ilgili işlem(sched)
        eGIS_TASK_MANAGER.schedule();
    }
    //operating system exit critical
    eGIS_INTERRUPT_MANAGER.setIntStatus(oldIntStatus);
}
