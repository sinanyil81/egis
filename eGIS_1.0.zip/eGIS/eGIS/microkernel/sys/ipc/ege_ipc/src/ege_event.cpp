#include "../../../../include/egis_kernel.h"
#include "../inc/ege_ipc.h"
using namespace eGe_Ipc;

eGe_Event::eGe_Event() {}
eGe_Event::~eGe_Event() {}

//burada bahsedilen 3 method cagrimlari esnasinda interruptların kapalı oldugu kabul edilir

void eGe_Event::eventWaitListInit() {
    eGe_PriorityQueueIpc queue;
    queue.priorityQueueListInit(this);
}

uint8_t eGe_Event::eventTaskReady() {
    uint8_t removedTaskID;

    eGe_PriorityQueueIpc queue;
    removedTaskID=queue.removeTask(this);

    //TASK ile ilgili olacak işlemler
    eGe_Task *task=(eGe_Task *)eGIS_TASK_MANAGER.returnTask(removedTaskID);
    eGIS_TASK_MANAGER.wakeUpTask((eGIS_TaskId)task);

    return removedTaskID;
}

void eGe_Event::eventTaskWait() {

    eGe_Task *task=(eGe_Task *)eGIS_TASK_MANAGER.returnCurrentTask();

    //current task ın priority sinden çıkan task_x ve task_y burada kullanıyor
    eGe_PriorityQueueIpc queue;
    queue.addTask(this,(uint8_t)task->_priority);

    //TASK ile ilgili olacak işlemler
    eGIS_TASK_MANAGER.waitTask((eGIS_TaskId)task);
}
