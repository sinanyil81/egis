#define TEST

#include "../../../../../include/types/egis_types.h"
#include "../../inc/ege_ipc.h"
#include <stdio.h>

using namespace std;
using namespace eGe_Ipc;

class eGe_Event_Test : public eGe_Event
  {
  public:
    void testEventWaitListInit()
    {
      eventWaitListInit();
    }
    void testTaskReady()
    {
      eventTaskReady();
    }
    void testEventTaskWait()
    {
      eventTaskWait();
    }
  };

class eGe_Semaphore_Test: public eGe_Semaphore
  {
  public:
    void valuePrint()
    {
      printf("semaphore value is %d\n",_value);
    }
  };

class eGe_Mutex_Test : public eGe_Mutex
  {
  public:
    void valuePrint()
    {
      printf("mutex value is %d\n",_lockValue);
    }
    void ownerPrint()
    {
      printf("mutex owner is %d\n",_ownerTaskID);
    }
    void setValue(int8_t v)
    {
      _lockValue=v;
    }
  };

void evenTest();
void semaphoreTest();
void mutexTest();
void queueTest();

int main(int argc, char *argv[])
{

  printf("-----------------mutex test----------------\n");
  mutexTest();
  printf("-----------------queue test----------------\n");
  queueTest();
  printf("---------------semaphore test--------------\n");
  semaphoreTest();
  printf("-----------------event test----------------\n");
  evenTest();
  return 0;
}

void evenTest()
{
  eGe_Event_Test event;
  event.testEventWaitListInit();

  event.eventGrup=0x01;
  event.eventTable[0]=0x04;
  event.eventTable[0] |= 0x02;


  event.testTaskReady();
  //     event.testTaskReady();
  event.testEventTaskWait();

  printf("eventGrup %d\n",event.eventGrup);

  printf("event table \n");

  for (int i=0;i<8;++i)
    {
      printf("%d\n",event.eventTable[i]);
    }
}

void semaphoreTest()
{
  eGe_Semaphore_Test sem;
  sem.eventGrup=0x01;
  sem.eventTable[1] |= 0x02;
  sem.eventTable[0] |= 0x04;
  sem.init(2);

  sem.valuePrint();
  sem.post();
  sem.valuePrint();
  sem.wait();
  sem.wait();
  sem.wait();
  sem.valuePrint();

  printf("eventGrup %d\n",sem.eventGrup);

  printf("event table \n");

  for (int i=0;i<8;++i)
    {
      printf("%d\n",sem.eventTable[i]);
    }
}

void mutexTest()
{
  eGe_Mutex_Test mutex;
  //     mutex.eventGrup=0x01;
  //     mutex.eventTable[0] |= 0x04;
  //     mutex.setValue(0);
  //     mutex.unlock();
  //     mutex.valuePrint();
  //     mutex.ownerPrint();
  mutex.lock();
  mutex.valuePrint();
  mutex.ownerPrint();
  mutex.lock();
  mutex.valuePrint();
  mutex.ownerPrint();

  printf("eventGrup %d\n",mutex.eventGrup);

  printf("event table \n");

  for (int i=0;i<8;++i)
    {
      printf("%d\n",mutex.eventTable[i]);
    }


  mutex.unlock();
  mutex.valuePrint();
  mutex.ownerPrint();

  printf("eventGrup %d\n",mutex.eventGrup);

  printf("event table \n");

  for (int i=0;i<8;++i)
    {
      printf("%d\n",mutex.eventTable[i]);
    }

  mutex.unlock();
  mutex.valuePrint();
  mutex.ownerPrint();

  mutex.unlock();
  mutex.valuePrint();
  mutex.ownerPrint();

  printf("eventGrup %d\n",mutex.eventGrup);

  printf("event table \n");

  for (int i=0;i<8;++i)
    {
      printf("%d\n",mutex.eventTable[i]);
    }
}

void queueTest()
{
  eGe_Queue queue;

  void *msg;
  msg=queue.wait();
  printf("queue test1 is %s\n",(msg) ? "FAILED" : "OK");
  printf("eventGrup %d\n",queue.eventGrup);

  printf("event table \n");

  for (int i=0;i<8;++i)
    {
      printf("%d\n",queue.eventTable[i]);
    }

  char a[3]="ab";
  queue.post((void *)&a);
  queue.post((void *)&a);
  queue.post((void *)&a);
  queue.post((void *)&a);
  queue.post((void *)&a);
  queue.post((void *)&a);
  queue.post((void *)&a);
  msg=queue.wait();
  printf("queue test2 is %s\n",msg);
  uint8_t ret=queue.post((void *)&a);
  printf("is overflow is %s\n",ret ? "fail" : "ok");
  ret=queue.post((void *)&a);
  printf("is overflow is %s\n",ret ? "fail" : "ok");
  ret=queue.post((void *)&a);
  printf("is overflow is %s\n",ret ? "fail" : "ok");
  /*
      msg=queue.wait();
      printf("msg is %s\n",(char *)msg);
      msg=queue.wait();
      printf("msg is %s\n",(char *)msg);
      msg=queue.wait();
      printf("msg is %s\n",(char *)msg);
      */
  printf("eventGrup %d\n",queue.eventGrup);

  printf("event table \n");

  for (int i=0;i<8;++i)
    {
      printf("%d\n",queue.eventTable[i]);
    }
}
