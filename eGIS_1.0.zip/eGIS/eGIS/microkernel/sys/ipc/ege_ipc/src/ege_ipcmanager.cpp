#include "../../../../include/egis_kernel.h"
#include "../inc/ege_ipc.h"

using namespace eGe_Ipc;

eGe_IpcManager::eGe_IpcManager() {
    for(uint8_t i=0 ; i<MAX_MUTEX_COUNT ; i++) {
        _MUTEXES[i]._oid = 0xFF;
        _SEMAPHORES[i]._oid = 0xFF;
    }
    _QUEUES[0]._oid=0xFF;
    _QUEUES[1]._oid=0xFF;
}

/**
*
*/
eGIS_Mutex *eGe_IpcManager::allocMutex() {
    for(uint8_t i=0 ; i<MAX_MUTEX_COUNT ; i++) {
        if(_MUTEXES[i]._oid == 0xFF) {
            _MUTEXES[i]._oid = i;
            return &_MUTEXES[i];
        };
    }

    return 0x0;
}

/**
*
*/
eGIS_Semaphore *eGe_IpcManager::allocSemaphore() {
    for(uint8_t i= 0 ; i< MAX_SEMAPHORE_COUNT ; i++) {
        if(_SEMAPHORES[i]._oid == 0xFF) {
            _SEMAPHORES[i]._oid = i;
            return &_SEMAPHORES[i];
        };
    }

    return 0x0;
}

eGIS_Queue *eGe_IpcManager::allocQueue() {
    for(uint8_t i= 0 ; i< MAX_QUEUE_COUNT; i++) {
        if(_QUEUES[i]._oid == 0xFF) {
            _QUEUES[i]._oid = i;
            return &_QUEUES[i];
        };
    }

    return 0x0;
}

/**
*
*/
void eGe_IpcManager::freeMutex(eGIS_Mutex *mutex) {
    mutex->_oid = 0xFF;
}

/**
*
*/
void eGe_IpcManager::freeSemaphore(eGIS_Semaphore *semaphore) {
    semaphore->_oid = 0xFF;
}

void eGe_IpcManager::freeQueue(eGIS_Queue *queue) {
    queue->_oid = 0xFF;
}
