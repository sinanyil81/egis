#include "../../../../include/egis_kernel.h"
#include "../inc/ege_ipc.h"
using namespace eGe_Ipc;

eGe_Queue::eGe_Queue() {
    eventWaitListInit();
    _head=0;
    _tail=_head;
    _entry=0;
}

eGe_Queue::~eGe_Queue() {}

void *eGe_Queue::wait() {
    //operating system enter critical

    eGIS_IntStatus oldIntStatus = eGIS_INTERRUPT_MANAGER.setIntStatus(INT_OFF);

    void *msg;

    if (_entry) {
        msg=_messageTable[_head];
        _entry--;
        if (_head==MAX_QUEUE_SIZE-1)
            _head=0;
        else
            _head++;
        return msg;
    } else {
        eventTaskWait();
        return (void *)0;
    }
    //TASK ile ilgili yapilacak işlem (sched)
    eGIS_TASK_MANAGER.schedule();

    eGIS_INTERRUPT_MANAGER.setIntStatus(oldIntStatus);
}

uint8_t eGe_Queue::post(void *msg) {
    //operating system enter critical
    eGIS_IntStatus oldIntStatus = eGIS_INTERRUPT_MANAGER.setIntStatus(INT_OFF);

    if (eventGrup) {
        eventTaskReady();
        //TASK ile ilgili işlem (sched)
        eGIS_TASK_MANAGER.schedule();
        //operating system exit critical
        eGIS_INTERRUPT_MANAGER.setIntStatus(oldIntStatus);
        return 1;
    } else {
        if (_entry==MAX_QUEUE_SIZE) {
            //operating system exit critical
            eGIS_INTERRUPT_MANAGER.setIntStatus(oldIntStatus);
            return 0;
        } else {
            _messageTable[_tail]=msg;
            _entry++;
            if (_tail==MAX_QUEUE_SIZE-1)
                _tail=0;
            else
                _tail++;
            //operating system exit critical
            eGIS_INTERRUPT_MANAGER.setIntStatus(oldIntStatus);
            return 1;
        }
    }
}
