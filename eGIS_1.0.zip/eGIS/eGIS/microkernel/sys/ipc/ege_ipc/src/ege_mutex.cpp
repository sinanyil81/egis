#include "../../../../include/egis_kernel.h"
#include "../inc/ege_ipc.h"
using namespace eGe_Ipc;

eGe_Mutex::eGe_Mutex() {
    eventWaitListInit();
    _lockValue=1;
    _ownerTaskID=65;
}

eGe_Mutex::~eGe_Mutex() {}

void eGe_Mutex::init() {}

void eGe_Mutex::lock() {

    //     operating system enter critical
    eGIS_IntStatus oldIntStatus = eGIS_INTERRUPT_MANAGER.setIntStatus(INT_OFF);

    if (_lockValue)
        _lockValue=0;
    else
        eventTaskWait();
    //TASK ile ilgili işlemler (sched)
    eGIS_TASK_MANAGER.schedule();

    //operating system exit critical
    eGIS_INTERRUPT_MANAGER.setIntStatus(oldIntStatus);
}

void eGe_Mutex::unlock() {

    //     operating system enter critical
    eGIS_IntStatus oldIntStatus = eGIS_INTERRUPT_MANAGER.setIntStatus(INT_OFF);

    if (!eventGrup) {
        _lockValue=1;
        //owner task icin getCurrent task id alınmali
        _ownerTaskID=((eGe_Task *)eGIS_TASK_MANAGER.returnCurrentTask())->_priority;
    } else {
        _ownerTaskID=eventTaskReady();
    }

    //TASK ile ilgili işlemler (sched)
    eGIS_TASK_MANAGER.schedule();

    //operating system exit critical
    eGIS_INTERRUPT_MANAGER.setIntStatus(oldIntStatus);
}
