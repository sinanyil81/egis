#ifndef ARCH_EGIS_INTERRUPT_H_
#define ARCH_EGIS_INTERRUPT_H_

#ifdef LINUX_INT
#define arch_eGIS_Interrupt Linux_Interrupt
#include "../../arch/linux/inc/linux_interrupt.h"

#else

#ifdef i386_INT
#define arch_eGIS_Interrupt i386_Interrupt
#include "../../arch/i386/inc/i386_interrupt.h"
#endif//i386_INT endif

#endif//LINUX_INT endif 

#endif

