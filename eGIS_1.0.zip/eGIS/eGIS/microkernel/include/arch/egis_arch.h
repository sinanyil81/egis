#ifndef EGIS_ARCH_H_
#define EGIS_ARCH_H_

#include "arch_egis_interrupt.h"

#ifdef i386_TASKCONTEXT

#define arch_eGIS_TaskContextFactory  i386_TaskContextFactory
#define arch_eGIS_TaskContext i386_TaskContext
#include "../../arch/i386/inc/i386.h"

#else

#ifdef LINUX_TASKCONTEXT

#define arch_eGIS_TaskContextFactory  Linux_TaskContextFactory
#define arch_eGIS_TaskContext Linux_TaskContext
#include "../../arch/linux/inc/linux.h"

#endif//LINUX_TASKCONTEXT endif

#endif//i386_TASKCONTEXT endif

#endif

