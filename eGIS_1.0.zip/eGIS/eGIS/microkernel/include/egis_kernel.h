#ifndef EGIS_KERNEL_H_
#define EGIS_KERNEL_H_

#include  "../configure.h"
#include  "types/egis_types.h"
#include  "sys/int/egis_int.h"
#include  "sys/kmem/egis_kmem.h"
#include  "sys/sched/egis_sched.h"
#include  "sys/ipc/egis_ipc.h"
#include  "arch/egis_arch.h"

#define eGIS_KERNEL eGIS_Kernel::getKernel()
#define eGIS_TASK_MANAGER eGIS_KERNEL->_taskManager
#define eGIS_INTERRUPT_MANAGER eGIS_KERNEL->_interruptManager
#define eGIS_IPC_MANAGER eGIS_KERNEL->_ipcManager

class eGIS_Kernel : public eGIS_Object {
public:

    virtual ~eGIS_Kernel();

    static eGIS_Kernel *getKernel();

    eGIS_TaskManager _taskManager;
    eGIS_InterruptManager _interruptManager;
    eGIS_IpcManager _ipcManager;

protected:

    eGIS_Kernel();

protected:

    static eGIS_Kernel *_kernel;
};

#endif
