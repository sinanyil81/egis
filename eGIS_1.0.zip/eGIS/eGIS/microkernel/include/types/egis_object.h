#ifndef EGIS_OBJECT_H_
#define EGIS_OBJECT_H_

typedef uint32_t eGIS_ObjectId;

class eGIS_Object
{
    public:

        eGIS_Object();
        virtual ~eGIS_Object();

        /* cekirdek nesneleri icin bellek, cekirdegin icinde yonetilir */
        void* operator new (uint32_t size);
        void* operator new[] (uint32_t size);
        void operator delete (void *ptr);
        void operator delete[] (void *ptr);

    public:

        eGIS_ObjectId _oid; /* object id */
};

#endif

