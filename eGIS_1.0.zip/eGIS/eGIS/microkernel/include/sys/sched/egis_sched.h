#ifndef EGIS_SCHED_H_
#define EGIS_SCHED_H_

typedef uint32_t eGIS_TaskId;
typedef uint32_t eGIS_TaskPriority;

enum eGIS_TaskState
{
	TASK_FREE,
	TASK_READY,
	TASK_RUNNING,
	TASK_WAITING,
	TASK_STOPPED,
	TASK_KILLED
};

typedef void * ( *eGIS_TaskEntryPoint ) ( void * );
typedef void *eGIS_TaskEntryParameter;

typedef void *eGIS_TaskStack;
typedef uint32_t eGIS_TaskStackSize;

typedef void *eGIS_AdditionalTaskInfo;

enum eGIS_SchedStatus
{
	SCHED_OFF,
	SCHED_ON
};

#include "egis_taskinfo.h"

#define eGe_TASKMANAGER

#ifdef eGe_TASKMANAGER

#include "../../arch/egis_arch.h"
#include "../../../sys/sched/ege_sched/inc/ege_sched.h"
#include "../../../sys/sched/ege_sched/inc/ege_taskmanager.h"

using namespace eGe_Sched;

#define eGIS_TaskManager eGe_TaskManager

#endif

#endif
