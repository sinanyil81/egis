#ifndef EGIS_KMEM_H_
#define EGIS_KMEM_H_

void *kmalloc(uint32_t size);
void kfree(void *ptr);

#endif

