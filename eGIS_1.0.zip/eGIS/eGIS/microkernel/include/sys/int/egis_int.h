#ifndef EGIS_INT_H_
#define EGIS_INT_H_

typedef uint32_t eGIS_InterruptNo;
typedef void (*eGIS_InterruptHandler) (void *);

enum eGIS_IntStatus
{
    INT_OFF,
    INT_ON
};

#include "egis_interruptmanager.h"

#endif

