#ifndef EGIS_INTERRUPT_MANAGER_H_
#define EGIS_INTERRUPT_MANAGER_H_

#define EGE_INT

#ifdef EGE_INT
#define eGIS_InterruptManager eGe_InterruptManager
#include "../../arch/arch_egis_interrupt.h"
#include "../../../sys/int/ege_int/inc/ege_int.h"
using namespace eGe_Int;
#endif

#endif
