#ifndef EGIS_IPC_H_
#define EGIS_IPC_H_

#define EGE_IPC

#ifdef EGE_IPC

#define eGIS_IpcManager eGe_IpcManager
#define eGIS_Mutex eGe_Mutex
#define eGIS_Semaphore eGe_Semaphore
#define eGIS_Queue eGe_Queue
#include "../../../sys/ipc/ege_ipc/inc/ege_ipc.h"
using namespace eGe_Ipc;

#endif

#endif

