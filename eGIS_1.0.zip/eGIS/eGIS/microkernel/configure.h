#define i386_TASKCONTEXT
#define i386_INT
#define NUM_TASKS 64
