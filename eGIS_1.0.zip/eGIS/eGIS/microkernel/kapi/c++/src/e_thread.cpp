#include "../../../include/egis_kernel.h"
#include "eGIS_c++.h"

using namespace eGIS;

/**
 * ilkleyici metod
 */
e_Thread::e_Thread(eGIS_TaskPriority priority) {
    _taskInfo._entry = e_Thread::MainEntry;
    _taskInfo._entryParam = this;
    _taskInfo._priority = priority;
    _taskInfo._stack = (void *)((uint32_t)(kmalloc(4096)) + 4096);
    _taskInfo._stackSize = 4096;
    _taskInfo._addInfo = 0;

    _pid = eGIS_TASK_MANAGER.createTask(&_taskInfo);
}

/**
 * sonlandirici metod
 */
e_Thread::~e_Thread() {}

/**
 *
 */
void *e_Thread::MainEntry(void *param) {
    e_Thread *thread = (e_Thread *)param;
    thread->entry();

    return (void *) 0x0;
}

/**
 *
 */
void e_Thread::start() {
    eGIS_TASK_MANAGER.startTask(_pid);
    eGIS_TASK_MANAGER.schedule();
}
