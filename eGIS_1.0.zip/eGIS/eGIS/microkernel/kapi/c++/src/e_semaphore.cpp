#include "../../../include/egis_kernel.h"
#include "eGIS_c++.h"

using namespace eGIS;

/**
 * 
 */
e_Semaphore::e_Semaphore() {

    _semaphore = 0;

}

/**
 * 
 */
e_Semaphore::~e_Semaphore() {
    eGIS_IPC_MANAGER.freeSemaphore(_semaphore);
}

/**
 * 
 */
void e_Semaphore::init(uint32_t init_value) {
    _semaphore = eGIS_IPC_MANAGER.allocSemaphore();
    _semaphore->init(init_value);
}

/**
 * 
 */
void e_Semaphore::post() {
    _semaphore->post();
}

/**
 * 
 */
void e_Semaphore::wait() {
    _semaphore->wait();
}
