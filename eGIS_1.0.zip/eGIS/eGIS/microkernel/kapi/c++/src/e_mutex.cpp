#include "../../../include/egis_kernel.h"
#include "eGIS_c++.h"

using namespace eGIS;

/**
 *
 */
e_Mutex::e_Mutex() {
    _mutex = 0;
}

/**
 *
 */
e_Mutex::~e_Mutex() {
    eGIS_IpcManager IPCManager = eGIS_IPC_MANAGER;
    IPCManager.freeMutex(_mutex);
}

/**
 *
 */
void e_Mutex::init() {
    eGIS_IpcManager IPCManager = eGIS_IPC_MANAGER;
    _mutex = IPCManager.allocMutex();
    _mutex->init();
}

/**
 *
 */
void e_Mutex::lock() {
    _mutex->lock()
    ;
}

/**
 *
 */
void e_Mutex::unlock() {
    _mutex->unlock();
}
