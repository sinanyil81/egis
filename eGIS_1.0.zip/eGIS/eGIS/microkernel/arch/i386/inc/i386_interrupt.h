#ifndef i386_INTERRUPT_H_
#define i386_INTERRUPT_H_

class i386_Interrupt : public eGIS_Object
{
    public:

        i386_Interrupt();
        virtual ~i386_Interrupt();

        void init();
        void enableInts();
        void disableInts();

        void registerHandler(eGIS_InterruptNo  interrupt_no,eGIS_InterruptHandler handler = 0);
        void unregisterHandler(eGIS_InterruptNo  interrupt_no);
};

/* kesme kimlik numaralari */
#define DIVIDE_ERROR                        0x0
#define DEBUG_EXCEPTION                 0x1
#define NMI_INTERRUPT                       0x2
#define BREAK_POINT_EXCEPTION           0x3
#define OVERFLOW_EXCEPTION              0x4
#define BOUND_RANGE_EXCEEDED            0x5
#define INVALID_OPCODE_EXCEPTION        0x6
#define DEVICE_NOT_AVAILABLE            0x7
#define DOUBLE_FAULT_EXCEPTION          0x8
#define COPROCESSOR_SEGMENT_OVERRUN     0x9
#define INVALID_TSS_EXCEPTION           0xA
#define SEGMENT_NOT_PRESENT             0xB
#define STACK_FAULT_EXCEPTION           0xC
#define GENERAL_PROTECTION_EXCEPTION    0xD
#define PAGE_FAULT_EXCEPTION            0xE
#define RESERVED                        0xF 
#define FLOATING_POINT_ERROR            0x10
#define IRQ_8                           0x70
#define IRQ_9                           0x71
#define IRQ_10                          0x72
#define IRQ_11                          0x73
#define IRQ_12                          0x74
#define IRQ_13                          0x75
#define IRQ_14                          0x76
#define IRQ_15                          0x77
#define IRQ_0                           0x78
#define IRQ_1                           0x79
#define IRQ_2                           0x7A
#define IRQ_3                           0x7B
#define IRQ_4                           0x7C
#define IRQ_5                           0x7D
#define IRQ_6                           0x7E
#define IRQ_7                           0x7F
#define DEFAULT                         0xFF

#endif
