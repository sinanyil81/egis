#ifndef i386_TASKCONTEXTFACTORY_H_
#define i386_TASKCONTEXTFACTORY_H_

/**
 * intel 386 platformuna uygun baglam donduren fabrika sinifi 
 */
class i386_TaskContextFactory : public eGIS_Object {

public:
    i386_TaskContextFactory();
    virtual ~i386_TaskContextFactory();

    /* platfomra ozgu baglamlari dondurur */
    arch_eGIS_TaskContext *returnContext();
private:
    arch_eGIS_TaskContext _contexts[NUM_TASKS];
};

#endif
