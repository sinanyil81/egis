typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef unsigned short int uint16_t;
typedef short int int16_t;
typedef unsigned int uint32_t;
typedef int int32_t;

#include "intel386_boot_i386.h"

#define KERNEL_ADDRESS 0x9000
#define KERNEL_SECTOR_SIZE 128 

/**
 * 
 */
void waitdisk(void)
{
    /* diskin hazir olmasini bekle */
    while ((inb(0x1F7) & 0xC0) != 0x40);
}

/**
 * 
 */
void readsector(void *dst, uint32_t offset)
{
    /* diski bekle */
    waitdisk();

    outb(0x1F2, 1);     // sayi = 1
    outb(0x1F3, offset);
    outb(0x1F4, offset >> 8);
    outb(0x1F5, offset >> 16);
    outb(0x1F6, (offset >> 24) | 0xE0);
    outb(0x1F7, 0x20);  // komut  0x20 - sektor oku
    
    /* diski bekle */
    waitdisk();
    
    insl(0x1F0, (uint8_t *)dst, 512/4);
}

/**
 * 
 */
void loadKernel()
{
    uint32_t sector = 1;
    uint32_t counter = 0;
    uint8_t  *addres = (uint8_t *)KERNEL_ADDRESS;
    
    while (counter < KERNEL_SECTOR_SIZE) 
    {
        readsector(addres, sector);
        addres += 512;
        sector++;
        counter++;
    }
}
