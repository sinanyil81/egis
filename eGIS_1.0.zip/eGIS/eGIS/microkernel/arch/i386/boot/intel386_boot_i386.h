/**
 * 
 */
static __inline void insl(int port, void *addr, int cnt)
{
    __asm __volatile("cld\n\trepne\n\tinsl"         :
             "=D" (addr), "=c" (cnt)        :
             "d" (port), "0" (addr), "1" (cnt)  :
             "memory", "cc");
}

/**
 * 
 */
 static __inline uint8_t inb(int port)
{
    uint8_t data;
    __asm __volatile("inb %w1,%0" : "=a" (data) : "d" (port));
    return data;
}

/**
 * 
 */
static __inline void outb(int port, uint8_t data)
{
    __asm __volatile("outb %0,%w1" : : "a" (data), "d" (port));
}
