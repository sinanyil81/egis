#include "../../../include/egis_kernel.h"
#include "i386.h"

i386_TaskContextFactory::i386_TaskContextFactory() {}

i386_TaskContextFactory::~i386_TaskContextFactory() {}

/**
 * intel 386 platformu icin yeni bir s�rec baglami yaratir.
 */
arch_eGIS_TaskContext *i386_TaskContextFactory::returnContext() {
            for( int i=0; i<NUM_TASKS; ++i) {
                if (!_contexts[i]._inUse) {
                    _contexts[i]._inUse=1;
                    return &_contexts[i];
                }
            }
            return 0x0;
        }
