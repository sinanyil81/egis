#ifndef i386_DESCRIPTORS_H_
#define i386_DESCRIPTORS_H_

/**
 * intel 32 bit mimarisindeki Bellek Tanimlayicisi 
 * (Descriptor) yapisi
 */
struct i386_Descriptor
{
    unsigned int    limit_low:16 ,    // Limit 0-15
                    base_low :16 ,    // Base 0-15
                    base_mid :8  ,    // Base 16-23
                    access_rights:8 , // Descriptor'un erisim haklari
                    limit_high:4 ,    // Limit 16-19
                    size:4 ,          // Descriptor'un b�y�kl�k bilgileri
                    base_high:8 ;     // Base 24-31
};

/**
 * intel 32 bit mimarisindeki Kapi (Gate) yapisi
 */
struct i386_Gate
{
    unsigned int    offset_low:16 ,   // Offset 0-15
                    selector:16 ,     // Segment selector 0-15
                    p_count:8 ,       // Parametre sayisi (4 bit)
                    access_rights:8 , // Kapinin erisim haklari
                    offset_high:16  ; // Offset 16-31
};

/**
 * LDTR ve GDTR yazmaclarini yukleyebilmek icin 
 * gerekli olan yapi
 */
struct i386_Memory_Register
{
    unsigned short limit;   // Limit
    unsigned long base;     // taban adresi
};

/**
 * Bellek tanimlayicilarini doldurmak icin gerekli sabitler
 * asagida tanimlanmistir
 */

// Segment buyuklugu ile ilgili ozellikler
#define PAGE_GRANULARITY  0x80       // segment buyuklugu sayfa olcusunde
#define SEGMENT_32_BIT    0x60       // 32 bit segment
#define AVAILABLE         0x10       // sistem yazilimlari tarafindan kullanima uygun 

// Erisim haklari ile ilgili ozellikler
#define PRESENT  0x80 // segment hafizada ve kullanilabilir.
#define DPL1     0x20 // Descriptor Privilege Level=1
#define DPL2     0x40 // Descriptor Privilege Level=2
#define DPL3     0x60 // Descriptor Privilege Level=3

// Kod veya Veri segmentleri icin �zellikler
#define DATA_READ 0x10                // read only
#define DATA_READWRITE 0x12           // read/write
#define STACK_READ 0x14               // read only
#define STACK_READWRITE 0x16          // read/write
#define CODE_EXEC 0x18                // exec only
#define CODE_EXECREAD 0x1A            // exec/read
#define CODE_EXEC_CONFORMING 0x1C     // exec only conforming
#define CODE_EXECREAD_CONFORMING 0x1E // exec/read conforming

#define ACCESSED 0x01 // o bellek b�lgesine erisim oldu mu?

// Sistem tanimlayicilari icin ozellikler
#define LDT 0x02            // Local Descriptor Table
#define TASK_GATE 0x05      // Sistem G�rev Kapisi
#define TSS 0x09            // G�rev Durum Segmenti (Task State Segment)
#define CALL_GATE 0x0C      // Cagirma Kapisi
#define INTERRUPT_GATE 0x0E // Kesme Kapisi 
#define TRAP_GATE 0x0F      // Yazilim Kesme Kapisi

// EFLAGS yazmacindaki bit haritasi
#define EFLG_ID         (1<<21)
#define EFLG_VIP        (1<<20)
#define EFLG_VIF        (1<<19)
#define EFLG_AC         (1<<18)
#define EFLG_VM         (1<<17)
#define EFLG_RF         (1<<16)
#define EFLG_NT         (1<<14)
#define EFLG_IOPL0      (0<<12)
#define EFLG_IOPL1      (1<<12)
#define EFLG_IOPL2      (2<<12)
#define EFLG_IOPL3      (3<<12)
#define EFLG_IOPLSHFT   12
#define EFLG_OF         (1<<11)
#define EFLG_DF         (1<<10)
#define EFLG_IF         (1<<9)
#define EFLG_TF         (1<<8)
#define EFLG_SF         (1<<7)
#define EFLG_ZF         (1<<6)
#define EFLG_AF         (1<<4)
#define EFLG_PF         (1<<2)
#define EFLG_CF         (1<<0)

// sistemdeki tanimlayicilar
#define CS_SELEKTORU    0x08
#define DS_SELEKTORU    0x10

/**
 * Bu fonksiyonlar GDT,IDT ve LDT tablolarini dinamik olarak degistirmek icin
 * kullanilirlar.Calisma zamaninda yeni eklemeler yapilir veya var olan deger-
 * ler degistirilebilir.
 */
void FillGate(struct i386_Gate *gate,
                 unsigned long offset,
                 unsigned short selector,
                 unsigned char parametre_sayisi,
                 unsigned char access);

void FillDescriptor(struct i386_Descriptor *desc,
                       unsigned long limit,
                       unsigned long base,
                       unsigned char access,
                       unsigned char size);

#endif
