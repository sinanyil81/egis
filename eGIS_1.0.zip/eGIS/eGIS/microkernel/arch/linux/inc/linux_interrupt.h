#ifndef LINUX_INTERRUPT_H_
#define LINUX_INTERRUPT_H_

class Linux_Interrupt : public eGIS_Object
{
    public:

        Linux_Interrupt();
        virtual ~Linux_Interrupt();

        void init();
        void enableInts();
        void disableInts();

        void registerHandler(eGIS_InterruptNo  interrupt_no,eGIS_InterruptHandler handler = 0);
        void unregisterHandler(eGIS_InterruptNo  interrupt_no);
};

#endif
