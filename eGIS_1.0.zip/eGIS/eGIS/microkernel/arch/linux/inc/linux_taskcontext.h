#ifndef LINUX_TASKCONTEXT_H_
#define LINUX_TASKCONTEXT_H_

/**
 * LINUX platformu icin donanimsal surec
 * bilgilerini tutacak olan sinif
 */
class Linux_TaskContext 
{
    public :

        Linux_TaskContext();
        virtual ~Linux_TaskContext();

        void init(eGIS_Object *init_param);
        void switchTo(arch_eGIS_TaskContext *newContext);
        
        static void *LinuxTaskEntry(void *param);

    public :
     
        eGIS_TaskInfo _taskInfo;
        pthread_t _thread;
        sem_t  _sem;
};

#endif

