#include "../../../include/egis_kernel.h"
#include "linux.h"

/**
 *
 */
Linux_Interrupt::Linux_Interrupt()
{

}

/**
 *
 */
Linux_Interrupt::~ Linux_Interrupt()
{

}

/**
 *
 */
void Linux_Interrupt::init()
{

}

/**
 *
 */
void Linux_Interrupt::enableInts()
{
    
}

/**
 *
 */
void Linux_Interrupt::disableInts()
{
    
}

/**
 *
 */
void Linux_Interrupt::registerHandler(eGIS_InterruptNo  interrupt_no,eGIS_InterruptHandler handler)
{
    handler = handler;
}

/**
 * 
 */
void Linux_Interrupt::unregisterHandler(eGIS_InterruptNo  interrupt_no)
{

}
