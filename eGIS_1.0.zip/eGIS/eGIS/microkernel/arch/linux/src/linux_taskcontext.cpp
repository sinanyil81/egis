#include "../../../include/egis_kernel.h"
#include "linux.h"

/**
 * ilkleyici metod
 */
Linux_TaskContext::Linux_TaskContext()
{

}

/**
 * sonlandirici metod
 */
Linux_TaskContext::~Linux_TaskContext()
{

}

/**
*
*/
void *Linux_TaskContext::LinuxTaskEntry(void *param)
{
    Linux_TaskContext *context = (Linux_TaskContext *)param;

    int retval;

    while ((sem_wait(&context->_sem)== -1) && (errno == EINTR))
        continue;       /* Restart when interrupted by handler */

    /* jump to entry method */
    context->_taskInfo._entry(context->_taskInfo._entryParam);

    pthread_exit(0);   

    return (void *)0; 
}

/**
 * surece ait baglami ilkler. Boylelikle surec duzgun bir sekilde 
 * calismaya baslayabilecektir.
 */
void Linux_TaskContext::init(eGIS_Object *init_param)
{
    /* save task creation info */
    _taskInfo = *((eGIS_TaskInfo *)init_param);

    sem_init(&_sem,0,0);

    pthread_create(&_thread,0,Linux_TaskContext::LinuxTaskEntry,(void *)this);
}

/**
 * surecler arasi gecisin yapildigi metod.
 */
void Linux_TaskContext::switchTo(arch_eGIS_TaskContext *newContext)
{
    Linux_TaskContext *context = (Linux_TaskContext *)newContext;

    /* make next process ready */
    sem_post(&(context->_sem));

    if(context != this)
    {
        /* wait this task */
        while ((sem_wait(&_sem) == -1) && (errno == EINTR))
            continue;       /* Restart when interrupted by handler */
        
    }
}
