#include "../../../include/egis_kernel.h"
#include "linux.h"

/**
 * linux platformu icin yeni bir s�rec baglami yaratir.
 */
arch_eGIS_TaskContext *Linux_TaskContextFactory::returnContext()
{
    return new Linux_TaskContext();
}
