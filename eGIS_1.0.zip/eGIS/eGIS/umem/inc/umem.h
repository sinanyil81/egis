#ifndef _UMEM_H_
#define _UMEM_H_

#include "../../microkernel/sys/kmem/ege_kmem/inc/ege_kmem.h"
#define Umem eGe_Memory::eGe_Kmem

#endif
