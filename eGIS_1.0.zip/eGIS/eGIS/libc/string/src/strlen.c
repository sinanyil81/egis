#include <../../include/sys/types.h>

size_t strlen(const char *s)
{
    size_t size = 0;

    while(*s++ != '\0')
        size++;

    return size;
}
