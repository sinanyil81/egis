#ifndef STRING_H_
#define STRING_H_

#ifdef __cplusplus
extern "C" {
#endif

extern void *memcpy(void *dest, const void *src, size_t n);
extern size_t strlen(const char *s);

#ifdef __cplusplus
}   /* extern "C" */
#endif

#endif /*STRING_H_*/
