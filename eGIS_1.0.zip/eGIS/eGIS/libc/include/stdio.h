#ifndef STDIO_H_
#define STDIO_H_

#ifdef __cplusplus
extern "C" {
#endif

extern void printf(char *str);
    
#ifdef __cplusplus
}   /* extern "C" */
#endif

#endif /*STDIO_H_*/
