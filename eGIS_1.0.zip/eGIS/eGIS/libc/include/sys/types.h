#ifndef _SYS_TYPES_H_
#define _SYS_TYPES_H_

typedef unsigned int size_t;

#endif /*_SYS_TYPES_H_*/
