#include <../../include/sys/types.h>
#include <../../include/string.h>

char * itoa ( int val, char * buffer, int base)
{
    static char buf[32] = {'\0'};

    int i = 30;
    unsigned int negative = 0;

    /* check base */    
    if (base == 0 || base > 16) 
    {
       buffer[0] = '\0';
        return buffer;
    }

    /* check value */ 
    if (val == 0) 
    {
        buffer[0] = '0';
        buffer[1] = '\0';

        return buffer;
    }

    if (val < 0) 
    {
        *buffer++= '-';
        val *= -1;
        negative = 1;
    }

    for(; val && i ; --i, val /= base)
    {
        buf[i] = "0123456789abcdef"[val % base];
    }

    memcpy(buffer,&buf[i+1],31 - i);

    return (negative) ? --buffer : buffer;
}
