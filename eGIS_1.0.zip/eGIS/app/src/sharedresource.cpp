#include "../../eGIS/microkernel/include/egis_kernel.h"
#include "../../eGIS/microkernel/kapi/c++/inc/eGIS_c++.h"
#include "../../eGIS/libc/include/stdio.h"

#include "sharedresource.h"

using namespace eGIS;

/**
 *
 */
SharedResource::SharedResource()
{
    _producerSem.init(1);
    _consumerSem.init(0);

    _producer = _consumer = 0;
}

/**
 *
 */
SharedResource::~SharedResource()
{

}

/**
 * 
 */
void SharedResource::produce()
{
    /* semafor uzerinde bekle */
    _producerSem.wait();

    _buffer[_producer] = 1;
    _producer =  ( _producer + 1 ) % QLEN;

    /* tuketici semaforunu postala */
    _consumerSem.post();
    printf("Consumer SEM posted...\n");
}

/**
 *
 */
void SharedResource::consume()
{
    /* semafor uzerinde bekle */
    _consumerSem.wait();

    _buffer[_producer] = 0;
    _consumer =  ( _consumer + 1 ) % QLEN;

    _producerSem.post();
    printf("Producer SEM posted...\n");
}
