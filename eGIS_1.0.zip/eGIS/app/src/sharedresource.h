#ifndef SHARED_RESOURCE_H_
#define SHARED_RESOURCE_H_

#define QLEN 64

class SharedResource
{
    public:

        SharedResource();
        virtual ~SharedResource();

        void produce();
        void consume();

    private:

        uint32_t _producer,_consumer;
        uint8_t _buffer[QLEN];
        eGIS::e_Semaphore _producerSem,_consumerSem;
};

#endif
