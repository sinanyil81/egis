#!/bin/bash
TOOL='i386'
TOOLSET=$TOOL
echo $TOOLSET
echo "system is cleanning"
make -f system.mak clean
clear
make -f system.mak
echo "system imaging"
make -f image.mak
